// Pixel-art text and the stone-block logo letters.

// ================= PIXEL FONT (5x7) =================
const GLYPHS = {};
`A 01110 10001 10001 11111 10001 10001 10001
B 11110 10001 10001 11110 10001 10001 11110
C 01110 10001 10000 10000 10000 10001 01110
D 11110 10001 10001 10001 10001 10001 11110
E 11111 10000 10000 11110 10000 10000 11111
F 11111 10000 10000 11110 10000 10000 10000
G 01110 10001 10000 10111 10001 10001 01111
H 10001 10001 10001 11111 10001 10001 10001
I 01110 00100 00100 00100 00100 00100 01110
J 00111 00010 00010 00010 00010 10010 01100
K 10001 10010 10100 11000 10100 10010 10001
L 10000 10000 10000 10000 10000 10000 11111
M 10001 11011 10101 10101 10001 10001 10001
N 10001 11001 10101 10011 10001 10001 10001
O 01110 10001 10001 10001 10001 10001 01110
P 11110 10001 10001 11110 10000 10000 10000
Q 01110 10001 10001 10001 10101 10010 01101
R 11110 10001 10001 11110 10100 10010 10001
S 01111 10000 10000 01110 00001 00001 11110
T 11111 00100 00100 00100 00100 00100 00100
U 10001 10001 10001 10001 10001 10001 01110
V 10001 10001 10001 10001 10001 01010 00100
W 10001 10001 10001 10101 10101 10101 01010
X 10001 10001 01010 00100 01010 10001 10001
Y 10001 10001 01010 00100 00100 00100 00100
Z 11111 00001 00010 00100 01000 10000 11111
0 01110 10001 10011 10101 11001 10001 01110
1 00100 01100 00100 00100 00100 00100 01110
2 01110 10001 00001 00010 00100 01000 11111
3 11110 00001 00001 01110 00001 00001 11110
4 00010 00110 01010 10010 11111 00010 00010
5 11111 10000 11110 00001 00001 10001 01110
6 00110 01000 10000 11110 10001 10001 01110
7 11111 00001 00010 00100 01000 01000 01000
8 01110 10001 10001 01110 10001 10001 01110
9 01110 10001 10001 01111 00001 00010 01100
. 00000 00000 00000 00000 00000 01100 01100
, 00000 00000 00000 00000 01100 00100 01000
! 00100 00100 00100 00100 00100 00000 00100
? 01110 10001 00001 00010 00100 00000 00100
: 00000 01100 01100 00000 01100 01100 00000
- 00000 00000 00000 11111 00000 00000 00000
+ 00000 00100 00100 11111 00100 00100 00000
/ 00001 00001 00010 00100 01000 10000 10000
% 11001 11010 00010 00100 01000 01011 10011
( 00010 00100 01000 01000 01000 00100 00010
) 01000 00100 00010 00010 00010 00100 01000
' 00100 00100 01000 00000 00000 00000 00000
< 00010 00100 01000 10000 01000 00100 00010
> 01000 00100 00010 00001 00010 00100 01000
= 00000 00000 11111 00000 11111 00000 00000
* 00000 10101 01110 11111 01110 10101 00000
_ 00000 00000 00000 00000 00000 00000 11111
[ 01110 01000 01000 01000 01000 01000 01110
] 01110 00010 00010 00010 00010 00010 01110
@ 01010 11111 11111 11111 01110 00100 00000
# 01010 11111 01010 01010 11111 01010 00000
; 00000 01100 01100 00000 01100 00100 01000`.split('\n').forEach(l => {
    GLYPHS[l[0]] = l.slice(2).split(' ');
});
const textCache = new Map();
function textImage(t, s, col, out, sh) {
    const key = t + '|' + s + '|' + col + '|' + (out || '') + '|' + (sh || '');
    let c = textCache.get(key);
    if (c) {
        return c;
    }
    if (textCache.size > 500) {
        textCache.clear();
    }
    const pad = out ? s : 0, ex = sh ? s : 0;
    c = document.createElement('canvas');
    c.width = Math.max(1, t.length * 6 * s + pad * 2 + ex);
    c.height = 7 * s + pad * 2 + ex;
    const x = c.getContext('2d');
    const gls = [...t.toUpperCase()].map(ch => GLYPHS[ch]);
    const pass = (ox, oy, color) => {
        x.fillStyle = color;
        gls.forEach((gl, i) => {
            if (!gl) {
                return;
            }
            for (let r = 0; r < 7; r++) {
                for (let q = 0; q < 5; q++) {
                    if (gl[r][q] == '1') {
                        x.fillRect(pad + ox + (i * 6 + q) * s, pad + oy + r * s, s, s);
                    }
                }
            }
        });
    };
    if (sh) {
        pass(s, s, sh);
    }
    if (out) {
        for (const [dx, dy] of [[-1, -1], [0, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [0, 1], [1, 1]]) {
            pass(dx * s, dy * s, out);
        }
    }
    pass(0, 0, col);
    textCache.set(key, c);
    return c;
}
const textWidth = (t, s) => Math.max(0, String(t).length * 6 - 1) * s;
function drawTextOn(ctx, t, x, y, s, col, o) {
    o = o || {};
    t = String(t);
    const c = textImage(t, s, col, o.out, o.sh), pad = o.out ? s : 0, w = textWidth(t, s);
    let dx = x;
    if (o.al == 'c') {
        dx = x - w / 2;
    }
    else if (o.al == 'r') {
        dx = x - w;
    }
    if (o.a != null) {
        ctx.globalAlpha = o.a;
    }
    ctx.drawImage(c, Math.round(dx - pad), Math.round(y - pad));
    ctx.globalAlpha = 1;
}
const drawText = (t, x, y, s, col, o) => drawTextOn(uiCtx, t, x, y, s, col, o);
// ================= MINECRAFT-STYLE BLOCK LETTERS =================
const blkC = {};
function blkLetter(ch, cell) {
    const key = ch + cell;
    if (blkC[key]) {
        return blkC[key];
    }
    const gl = GLYPHS[ch];
    const ex = Math.round(cell * .3);
    const c = document.createElement('canvas');
    c.width = 5 * cell + ex + 2;
    c.height = 7 * cell + ex + 2;
    const x = c.getContext('2d');
    let seed = ch.charCodeAt(0) * 977 + cell;
    const rnd = () => {
        seed = (seed * 16807) % 2147483647;
        return seed / 2147483647;
    };
    gl.forEach((row, r) => {
        for (let q = 0; q < 5; q++) {
            if (row[q] == '1') {
                x.fillStyle = '#07040f';
                x.fillRect(q * cell + ex, r * cell + ex, cell, cell);
            }
        }
    });
    gl.forEach((row, r) => {
        for (let q = 0; q < 5; q++) {
            if (row[q] != '1') {
                continue;
            }
            const px = q * cell, py = r * cell, k = rnd();
            const base = k < .07 ? [92, 140, 100] : k < .12 ? [214, 168, 58] : k < .42 ? [104, 106, 130] : k < .78 ? [122, 124, 150] : [86, 88, 114];
            const j = (rnd() - .5) * 16;
            x.fillStyle = `rgb(${base.map(v => Math.max(0, Math.min(255, v + j)) | 0).join(',')})`;
            x.fillRect(px, py, cell, cell);
            for (let i = 0; i < 6; i++) {
                const sx = px + 1 + ((rnd() * (cell - 4)) | 0), sy = py + 1 + ((rnd() * (cell - 4)) | 0);
                x.fillStyle = rnd() < .5 ? 'rgba(255,255,255,.16)' : 'rgba(0,0,0,.22)';
                x.fillRect(sx, sy, 2, 2);
            }
            const bw = Math.max(2, (cell * .16) | 0);
            x.fillStyle = 'rgba(255,255,255,.38)';
            x.fillRect(px, py, cell, bw);
            x.fillRect(px, py, bw, cell);
            x.fillStyle = 'rgba(0,0,0,.42)';
            x.fillRect(px, py + cell - bw, cell, bw);
            x.fillRect(px + cell - bw, py, bw, cell);
            x.fillStyle = 'rgba(7,4,15,.7)';
            x.fillRect(px, py, cell, 1);
            x.fillRect(px, py, 1, cell);
            x.fillRect(px, py + cell - 1, cell, 1);
            x.fillRect(px + cell - 1, py, 1, cell);
        }
    });
    return blkC[key] = c;
}
const easeBounce = t => {
    const n = 7.5625, d = 2.75;
    if (t < 1 / d) {
        return n * t * t;
    }
    if (t < 2 / d) {
        return n * (t -= 1.5 / d) * t + .75;
    }
    if (t < 2.5 / d) {
        return n * (t -= 2.25 / d) * t + .9375;
    }
    return n * (t -= 2.625 / d) * t + .984375;
};
// Draws the stone-block title logo, optionally dropping the letters in.
function logoOn(ctx, cx0, y0, cell, t, anim) {
    const words = ['UNRELIABLE', 'NARRATOR'];
    words.forEach((word, row) => {
        const wTot = (word.length * 6 - 1) * cell, x0 = cx0 - wTot / 2;
        [...word].forEach((ch, i) => {
            const k = anim ? Math.max(0, Math.min(1, (t - (row * 10 + i) * .05) / .55)) : 1;
            if (k <= 0) {
                return;
            }
            const drop = anim ? (1 - easeBounce(k)) * -340 : 0;
            let bob = anim ? Math.sin(time * 1.6 + i * .55 + row) * 3 : 0, jx = 0;
            if (anim && row == 0 && i < 2 && (time % 4) < .16) {
                if ((time * 40 | 0) % 2) {
                    return;
                }
                jx = (rand() - .5) * 8;
            }
            ctx.drawImage(blkLetter(ch, cell), Math.round(x0 + i * 6 * cell + jx), Math.round(y0 + row * (8 * cell + 10) + drop + bob));
        });
    });
}
