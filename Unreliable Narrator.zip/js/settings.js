// Saved settings and the keyboard bindings the game reads.

// ================= SETTINGS / KEY BINDINGS =================
const DEFAULT_KEYS = { left: ['KeyA', 'ArrowLeft'], right: ['KeyD', 'ArrowRight'], up: ['KeyW', 'ArrowUp'], down: ['KeyS', 'ArrowDown'], jump: ['Space', ''], attack: ['KeyJ', 'Space'], sprint: ['ShiftLeft', 'ShiftRight'], finish: ['KeyK', ''], ultimate: ['KeyL', ''] };
const ACTIONS = [['left', 'MOVE LEFT'], ['right', 'MOVE RIGHT'], ['up', 'UP / JUMP'], ['down', 'MOVE DOWN'], ['jump', 'JUMP'], ['attack', 'ATTACK'], ['sprint', 'SPRINT'], ['finish', 'FINISHER'], ['ultimate', 'ULTIMATE']];
let keyBindings = JSON.parse(JSON.stringify(DEFAULT_KEYS)), bestScore = 0;
function storeGet(k) {
    try {
        return localStorage.getItem(k);
    }
    catch (e) {
        return null;
    }
}
function storeSet(k, v) {
    try {
        localStorage.setItem(k, v);
    }
    catch (e) {
    }
}
// Reads saved volume and key settings from the browser.
function loadSettings() {
    try {
        const s = JSON.parse(storeGet('un_settings') || 'null');
        if (s) {
            if (typeof s.music == 'number') {
                settings.music = Math.max(0, Math.min(1, s.music));
            }
            if (typeof s.sfx == 'number') {
                settings.sfx = Math.max(0, Math.min(1, s.sfx));
            }
            if (typeof s.shake == 'number') {
                settings.shake = s.shake ? 1 : 0;
            }
            if (s.keys) {
                for (const a in DEFAULT_KEYS) {
                    if (Array.isArray(s.keys[a]) && s.keys[a].length == 2) {
                        keyBindings[a] = s.keys[a].map(String);
                    }
                }
            }
        }
    }
    catch (e) {
    }
    // the control style is saved on its own, and only when the player picks one,
    // so everyone starts with the joystick and a choice sticks on that device
    const savedPad = storeGet('un_pad');
    if (savedPad === 'touch' || savedPad === 'joystick') {
        settings.pad = savedPad;
    }
    bestScore = parseInt(storeGet('un_best') || '0', 10) || 0;
    applyVol();
}
// Saves volume and key settings in the browser.
function saveSettings() {
    storeSet('un_settings', JSON.stringify({ music: settings.music, sfx: settings.sfx, shake: settings.shake, keys: keyBindings }));
}
const TOUCH = {}; // on-screen buttons write into this (see touch.js)
const isHeld = a => keyBindings[a].some(c => c && keysDown[c]) || !!TOUCH[a];
const attackOnlyKeys = () => keyBindings.attack.filter(c => c && !keyBindings.jump.includes(c) && !keyBindings.up.includes(c));
const isAttackHeld = () => keyBindings.attack.some(c => c && keysDown[c]) || !!TOUCH.attack;
const isPlatformAttackHeld = () => attackOnlyKeys().some(c => keysDown[c]) || !!TOUCH.attack;
function keyName(c) {
    if (!c) {
        return '--';
    }
    const m = { Space: 'SPACE', ShiftLeft: 'L SHIFT', ShiftRight: 'R SHIFT', ControlLeft: 'L CTRL', ControlRight: 'R CTRL', AltLeft: 'L ALT', AltRight: 'R ALT', ArrowLeft: 'LEFT', ArrowRight: 'RIGHT', ArrowUp: 'UP', ArrowDown: 'DOWN', Enter: 'ENTER', Tab: 'TAB', Backspace: 'BKSP', Comma: ',', Period: '.', Slash: '/', Semicolon: ';', Quote: "'", BracketLeft: '[', BracketRight: ']', Minus: '-', Equal: '=' };
    if (m[c]) {
        return m[c];
    }
    if (c.startsWith('Key')) {
        return c.slice(3);
    }
    if (c.startsWith('Digit')) {
        return c.slice(5);
    }
    if (c.startsWith('Numpad')) {
        return 'NUM ' + c.slice(6);
    }
    return c.toUpperCase().slice(0, 9);
}
const firstKeyName = a => keyName(keyBindings[a].find(c => c) || '');
function hintText() {
    if (touchMode) {
        return gameState == 'act2' ? 'Stick: move   ATK: fire   RUN: sprint   FIN: finisher   ULT: ultimate' : 'Stick: move   JMP: jump   ATK: attack   RUN: sprint   FIN: finisher';
    }
    const at = attackOnlyKeys().map(keyName).join('/') || 'MOUSE';
    return gameState == 'act2' ? `Move: ${firstKeyName('up')} ${firstKeyName('left')} ${firstKeyName('down')} ${firstKeyName('right')}   Fire: ${keyBindings.attack.filter(c => c).map(keyName).join('/')}   Sprint: ${firstKeyName('sprint')}   Finish: ${firstKeyName('finish')}   Ultimate: ${firstKeyName('ultimate')}`
        : `Move: ${firstKeyName('left')}/${firstKeyName('right')}   Jump: ${firstKeyName('jump')}/${firstKeyName('up')}   Attack: ${at}   Sprint: ${firstKeyName('sprint')}   Finish: ${firstKeyName('finish')}`;
}
