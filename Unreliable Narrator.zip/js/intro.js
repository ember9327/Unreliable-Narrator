// Intro video: plays before the adventure starts, or from "Watch intro" on the title screen.

const introVideo = byId('introVideo');
const skipHint = byId('skipHint');
const skipLayer = byId('skipLayer');

let introThen = 'game';   // 'game' starts the adventure afterwards, 'menu' goes back to the title
let introDone = true;
let introStartedAt = 0;
let introTimer = null;
let introNeedsTap = false; // true when the browser blocked playback and wants a tap first

function startIntro(then) {
    introThen = then;
    introDone = false;
    introNeedsTap = false;
    introStartedAt = Date.now();
    gameState = 'intro';
    card = 0;
    narrationQueue = [];
    narration = {};
    deathState.on = false;
    paused = false;
    banner = null;
    popups = [];
    particles = [];

    // the video has its own music, so keep the game music quiet meanwhile
    musicDuck = 0;
    applyMusic(0.2);

    skipHint.textContent = touchMode ? 'TAP TO SKIP' : 'ENTER OR CLICK TO SKIP';
    skipHint.style.display = 'block';
    skipLayer.style.display = 'block';
    introVideo.style.display = 'block';
    introVideo.volume = Math.max(0.15, Math.max(settings.music, settings.sfx));
    introVideo.muted = false;
    introVideo.currentTime = 0;

    tryPlayIntro();

    // if the video never gets going (slow phone, file blocked) don't leave the player stuck
    clearTimeout(introTimer);
    introTimer = setTimeout(() => {
        if (!introDone && !introNeedsTap && introVideo.currentTime === 0) {
            endIntro();
        }
    }, 12000);
}

function tryPlayIntro() {
    const p = introVideo.play();
    if (!p || !p.catch) {
        return;
    }
    p.catch(() => {
        // browsers sometimes refuse sound without a proper tap, so try again muted
        introVideo.muted = true;
        const retry = introVideo.play();
        if (retry && retry.catch) {
            retry.catch(() => {
                // still blocked (e.g. iPhone low power mode): wait for a tap instead of skipping
                introNeedsTap = true;
                skipHint.textContent = 'TAP TO PLAY';
            });
        }
    });
}

function skipIntro() {
    if (introDone) {
        return;
    }
    // Phones fire a leftover mouse click right after the finger lifts. That click lands
    // on the skip layer and used to cancel the intro straight away, so ignore taps
    // in the first moment.
    if (Date.now() - introStartedAt < 800) {
        return;
    }
    if (introNeedsTap) {
        introNeedsTap = false;
        introVideo.muted = false;
        skipHint.textContent = touchMode ? 'TAP TO SKIP' : 'ENTER OR CLICK TO SKIP';
        tryPlayIntro();
        return;
    }
    endIntro();
    // the beep goes last so a sound problem can't stop the skip
    try {
        playUiSound('back');
    } catch (err) {
    }
}

function endIntro() {
    if (introDone) {
        return;
    }
    introDone = true;
    clearTimeout(introTimer);
    skipLayer.style.display = 'none';
    introVideo.pause();
    introVideo.style.display = 'none';
    skipHint.style.display = 'none';
    musicDuck = 1;
    applyMusic(0.6);
    if (introThen === 'game') {
        run();
        fadeIn();
    } else {
        gotoMenu();
    }
}

introVideo.addEventListener('ended', endIntro);

// if none of the video files can be played, carry on without the intro
const videoSources = introVideo.querySelectorAll('source');
videoSources[videoSources.length - 1].addEventListener('error', endIntro);

// taps and clicks on the layer skip the intro (all three are listened to for older Safari)
['pointerdown', 'touchstart', 'click'].forEach(type => {
    skipLayer.addEventListener(type, e => {
        e.preventDefault();
        e.stopPropagation();
        skipIntro();
    }, { passive: false });
});
