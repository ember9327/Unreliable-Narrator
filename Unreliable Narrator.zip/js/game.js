// The game itself: levels, enemies, player, boss fight, Act II and drawing.

// ---------- game state ----------
const keysDown = {};
let gameState = 'title', time = 0, t0 = 0, player, enemies = [], particles = [], rec = [], wave = 0, nw = 0, screenShake = 0, hitStop = 0, screenFlash = 0, flashColor = '255,255,255', gi = 0, card = 0, kills = 0, narrationQueue = [], narration = {}, cameraX = 0, scareT = 10, dripT = 5, hbT = 0;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const WV = [['s', 's', 's'], ['s', 's', 'b', 'b'], ['s', 'b', 's', 'b', 's']];
const CL = ['Splendid. They never stood a chance.', 'Magnificent! Now only the dragon remains…'];
const MO = Array.from({ length: 36 }, () => ({ x: rand() * GAME_W, y: rand() * GAME_H, s: 2 + rand() * 6, ph: rand() * 6 }));
const queueLine = (t, g, h, spk) => narrationQueue.push({ t, g, h, spk });
// ---------- Act 1 levels (side-scroll) ----------
let T = [], DOOR = { x: 0, y: 0 }, LEVEL_W = 0, level = 1, DEC = [];
// Builds one level layout from its settings.
function buildLevel(types) {
    let x = 0;
    const T = [], EN = [], DC = [];
    const nt = () => types[(rand() * types.length) | 0];
    const push = (len, y) => {
        T.push({ x0: x, x1: x + len, y });
        x += len;
    };
    push(150, 150);
    x += 28;
    push(90, 150);
    EN.push({ t: nt(), x0: x - 84, x1: x - 8, y: 150 });
    x += 30;
    push(64, 122);
    x += 36;
    push(170, 150);
    EN.push({ t: nt(), x0: x - 160, x1: x - 90, y: 150 });
    if (rand() < .7) {
        EN.push({ t: nt(), x0: x - 140, x1: x - 20, y: 104 });
    }
    x += 26;
    push(70, 128);
    x += 28;
    push(210, 150);
    EN.push({ t: nt(), x0: x - 195, x1: x - 120, y: 150 });
    if (rand() < .75) {
        EN.push({ t: nt(), x0: x - 90, x1: x - 16, y: 150 });
    }
    x += 30;
    push(80, 112);
    x += 34;
    push(230, 150);
    if (rand() < .8) {
        EN.push({ t: nt(), x0: x - 215, x1: x - 40, y: 100 });
    }
    EN.push({ t: nt(), x0: x - 60, x1: x - 14, y: 150 });
    x += 28;
    push(60, 132);
    x += 26;
    push(240, 150);
    EN.push({ t: nt(), x0: x - 220, x1: x - 140, y: 150 });
    if (rand() < .75) {
        EN.push({ t: nt(), x0: x - 130, x1: x - 30, y: 106 });
    }
    if (rand() < .8) {
        EN.push({ t: nt(), x0: x - 60, x1: x - 14, y: 150 });
    }
    x += 30;
    push(120, 150);
    T.forEach(s => {
        if (rand() < .5) {
            DC.push({ t: 'bones', x: s.x0 + 10 + rand() * Math.max(10, s.x1 - s.x0 - 20), y: s.y });
        }
    });
    for (let cx0 = 70; cx0 < x; cx0 += 130 + rand() * 50) {
        DC.push({ t: 'chain', x: cx0 });
    }
    for (let i = 0; i < T.length - 1; i++) {
        if (T[i + 1].x0 - T[i].x1 > 16 && rand() < .65) {
            DC.push({ t: 'eyes', x: (T[i].x1 + T[i + 1].x0) / 2, y: 96 + rand() * 44, ph: rand() * 10 });
        }
    }
    DC.push({ t: 'web', x: 14, y: 8, dir: 1 });
    DC.push({ t: 'web', x: x - 14, y: 8, dir: -1 });
    return { T, EN, DC, DOOR: { x: x - 46, y: 150 }, W: x };
}
let LEVELS = [];
// Generates the layouts for both levels.
function genLevels() {
    LEVELS = [buildLevel(['imp', 'bat', 'imp', 'bat', 'crawl']), buildLevel(['crawl', 'float', 'bat', 'imp', 'float', 'crawl'])];
}
const segAt = x => {
    for (let i = 0; i < T.length; i++) {
        if (x >= T[i].x0 && x <= T[i].x1) {
            return T[i];
        }
    }
    return null;
};
// Switches to a level and fills it with enemies.
function loadLvl(n) {
    level = n;
    const L = LEVELS[n - 1];
    T = L.T;
    DOOR = L.DOOR;
    LEVEL_W = L.W;
    DEC = L.DC;
    enemies = L.EN.map(e => ({ t: e.t, x0: e.x0, x1: e.x1, x: (e.x0 + e.x1) / 2, y: e.y, baseY: e.y, dir: 1, hp: (e.t == 'imp' || e.t == 'float') ? 2 : 1, ph: rand() * 2, fl: 0 }));
}
// Starts a brand new game from level 1.
function run() {
    genLevels();
    palette = PALETTE_DUNGEON;
    background = BACKGROUNDS[0];
    player = { x: 40, y: 150, ax: 1, ay: 0, f: 1, hp: 7, mh: 7, inv: 0, at: 0, cd: 0, w: 0, st: 0, mv: 0, vx: 0, vy: 0, onGround: 1, sprintT: 0, finT: 0, fbar: 0, finCd: 0 };
    cameraX = 0;
    loadLvl(1);
    particles = [];
    rec = [];
    wave = 0;
    nw = 1.2;
    card = 0;
    gi = 0;
    kills = 0;
    narrationQueue = [];
    narration = {};
    gameState = 'play';
    setMusic(0);
    t0 = time;
    resetStats();
    saveStageSnapshot();
    showBanner('LEVEL 1', 'Reach the door at the end');
    queueLine('Once upon a time, a brave knight set out for a cursed tower…', 0, 1.3);
    queueLine('Cross the tunnels. Clear a path to the door.', 0, 1.5);
}
// Spawns the next wave of enemies.
function spawnW() {
    WV[wave].forEach((t, i) => {
        let x, y;
        do {
            x = 20 + rand() * 280;
            y = 66 + rand() * 100;
        } while (Math.hypot(x - player.x, y - player.y) < 80);
        enemies.push({ t, x, y, hp: t == 's' ? 2 : 1, sp: .6 + i * .25, ph: rand() * 1.2, j: 0, kx: 0, ky: 0, vx: 0, vy: 0, fl: 0, hz: 0 });
    });
}
// Spawns a small burst of particles.
function burst(x, y, n, c) {
    for (let i = 0; i < n; i++) {
        particles.push({ x, y, vx: (rand() - .5) * 120, vy: (rand() - .8) * 90, l: .4 + rand() * .4, c });
    }
}
// The player takes damage (or dies when out of hearts).
function hurt(e) {
    player.hp--;
    player.inv = 1.7;
    screenShake = 5;
    screenFlash = .35;
    flashColor = '255,60,80';
    playSound('hurt');
    const dx = player.x - e.x, dy = player.y - e.y, l = Math.hypot(dx, dy) || 1;
    player.x += dx / l * 14;
    player.y += dy / l * 14;
    burst(player.x, player.y - 6, 10, '#ff5d73');
    if (player.hp <= 0) {
        playerDied();
    }
    else if (!narration.cur && !narrationQueue.length && rand() < .5) {
        queueLine(gameState == 'act2' ? 'Mere scratches. Dragons do not bleed, do they?' : 'A mere scratch. Heroes do not bleed.', 0, 1.2);
    }
}
// Swings the sword (or fires, in the top-down parts) and hits anything in range.
function attack() {
    const D = gameState == 'act2';
    player.cd = D ? .3 : .28;
    player.at = D ? .3 : .18;
    playSound(D ? 'fire' : 'swing');
    if (D) {
        for (let i = 0; i < 20; i++) {
            const a = Math.atan2(player.ay, player.ax) + (rand() - .5) * .8, v = 70 + rand() * 90;
            particles.push({ x: player.x + player.ax * 8, y: player.y - 8 + player.ay * 8, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 25, l: .25 + rand() * .25, c: ['#ff3d5a', '#ff8a3d', '#ffe9a8'][rand() * 3 | 0] });
        }
    }
    enemies.forEach(e => {
        if (e.sp > 0) {
            return;
        }
        const dx = e.x - player.x, dy = e.y - player.y, dd = Math.hypot(dx, dy) || 1, rg = e.t == 'D' ? 58 : (D ? 52 : 36);
        if (dd < rg && (dx * player.ax + dy * player.ay) / dd > (D ? 0 : -.45)) {
            e.hp--;
            e.fl = .12;
            e.kx = dx / dd * 210;
            e.ky = dy / dd * 210;
            playSound('hit');
            burst(e.x, e.y - 6, 8, '#fff');
            screenShake = 3;
            stop = .05;
            if (e.hp <= 0) {
                e.dead = 1;
            }
        }
    });
    enemies = enemies.filter(e => {
        if (e.dead) {
            if (e.t == 'D') {
                awardKill(e);
                stageBonus(300, 'DRAGON SLAIN');
                playSound('kill');
                burst(e.x, e.y - 10, 30, '#ff8a4a');
                screenShake = 9;
                screenFlash = .6;
                flashColor = '255,140,70';
                stop = .2;
                twist();
                return false;
            }
            if (D) {
                player.charge = clamp((player.charge || 0) + .16, 0, 1);
            }
            else {
                player.fbar = clamp((player.fbar || 0) + .3, 0, 1);
            }
            awardKill(e);
            kills++;
            playSound('kill');
            burst(e.x, e.y - 5, 16, e.t == 's' ? '#7fe3b5' : '#8a5cf0');
            stop = .08;
            screenShake = 4;
            if (kills == 1) {
                queueLine('Splendid! Another beast falls to your blade.', 0, 1.2);
            }
            return false;
        }
        return true;
    });
}
const BOSS_MAXHP = 9;
// Sets up the fight against the dragon.
function boss() {
    gameState = 'boss';
    cameraX = 0;
    player.x = 160;
    player.y = 140;
    player.ax = 1;
    player.ay = 0;
    player.finT = 0;
    player.finCd = 0;
    player.fbar = 0;
    player.hp = Math.max(player.hp, 4);
    enemies = [{ t: 'D', x: 160, y: 82, hp: BOSS_MAXHP, fl: 0, hz: 0, kx: 0, ky: 0, vx: 0, vy: 0, mode: 'intro', mt: 1.6, fired: 0, chg: 0, tgx: 160, tgy: 140 }];
    nw = 0;
    palette = PALETTE_DUNGEON;
    playSound('roar');
    screenFlash = .5;
    flashColor = '255,120,60';
    screenShake = 6;
    narrationQueue = [];
    narration = {};
    queueLine('So. Another knight climbs my tower to die.', 1, 1.6, 'The Dragon');
    queueLine('I did not come to die. I came to end this.', 0, 1.4, 'The Knight');
    queueLine('They all say that. None of them leave.', 1, 1.5, 'The Dragon');
    queueLine('Then I will be the first.', 0, 1.1, 'The Knight');
    queueLine('So. The dragon itself comes to end this quickly.', 0, 1.6);
    queueLine('Finish it, hero, and the tale is yours.', 0, 1.4);
    saveStageSnapshot();
    showBanner('THE DRAGON', 'Defeat it to finish the tale');
}
// The story twist: the dragon dies and the narrator turns out to be lying.
function twist() {
    a1t = time - t0;
    gameState = 'twist';
    enemies = [];
    gi = 0;
    playSound('boom');
    playSound('glitch');
    screenFlash = 1;
    flashColor = '255,255,255';
    screenShake = 10;
    palette = PALETTE_BLOOD;
    background = BACKGROUNDS[1];
    setMusic(-1);
    narration = {};
    narrationQueue = [];
    setTimeout(() => {
        if (gameState == 'twist') {
            setMusic(1);
        }
    }, 1600);
    [['…and so the hero reached the top of the tower.', 0, 1.2], ['Wait. That is not right.', 1, 1], ['The dragon was not guarding a prisoner. It was guarding a home.', 1, 1.8], ['The princess never called for a hero.', 1, 1.4], ['You were the one who broke in.', 1, 2.2]].forEach(a => queueLine(...a));
}
// Advances the narrator text box (typewriter effect and timing).
function narr(d) {
    if (!narration.cur) {
        if (!narrationQueue.length) {
            return;
        }
        narration = { cur: narrationQueue.shift(), i: 0, tm: 0, hd: 0 };
        if (narration.cur.g) {
            playSound('glitch');
            if (gameState == 'end') {
                setMusic(1);
                palette = PALETTE_BLOOD;
                background = BACKGROUNDS[1];
                screenShake = 6;
            }
        }
    }
    const c = narration.cur;
    narration.tm += d;
    const n = Math.min(c.t.length, narration.tm * 38 | 0);
    while (narration.i < n) {
        if (c.t[narration.i++] != ' ') {
            playSound('blip');
        }
    }
    if (narration.i >= c.t.length && (narration.hd += d) > (c.h || 2)) {
        narration = {};
        if (!narrationQueue.length && (gameState == 'twist' || gameState == 'end')) {
            card = gameState == 'end' ? 2 : 1;
        }
    }
}
let a1t = 60;
// Starts Act II, where the player is the dragon.
function act2(hp0) {
    gameState = 'act2';
    card = 0;
    palette = PALETTE_BLOOD;
    background = BACKGROUNDS[1];
    player = { x: 160, y: 130, ax: 0, ay: -1, f: 1, hp: hp0 || 8, mh: 8, inv: 0, at: 0, cd: 0, w: 0, st: 0, mv: 0, charge: 0, ultT: 0, utx: 160, uty: 130, finT: 0, finCd: 0 };
    enemies = [];
    particles = [];
    wave = 0;
    nw = 1.8;
    kills = 9;
    narrationQueue = [];
    narration = {};
    setMusic(1);
    t0 = time;
    playSound('roar');
    screenFlash = .6;
    flashColor = '255,90,70';
    queueLine('Defend your home, dragon. They come by the paths you carved.', 1, 1.6);
    queueLine('Every knight is a ghost of how you played.', 0, 1.6);
    saveStageSnapshot();
}
// Spawns ghost enemies for Act II.
function spawnG(n) {
    for (let i = 0; i < n; i++) {
        const j = rand() * rec.length | 0, r = rec[j] || [30, 150, 1];
        let x = r[0], y = r[1];
        if (Math.hypot(x - player.x, y - player.y) < 70) {
            x = i % 2 ? 24 : 296;
            y = 150;
        }
        enemies.push({ t: 'g', x, y, hp: 3, sp: .6 + i * .25, i: j, fl: 0, hz: 0, kx: 0, ky: 0, vx: 0, vy: 0 });
    }
}
// Act II special attack, available once the charge bar is full.
function ultimate() {
    if (gameState != 'act2' || (player.charge || 0) < 1 || player.ultT > 0) {
        return;
    }
    player.charge = 0;
    player.ultT = .55;
    player.utx = player.x;
    player.uty = player.y;
    playSound('telegraph');
}
// Finishing move on a weakened enemy, powered by the finisher bar.
function finisher() {
    if (gameState == 'boss') {
        if ((player.fbar || 0) < 1) {
            return;
        }
        const e = enemies[0];
        if (!e || e.mode == 'intro') {
            return;
        }
        const dx = e.x - player.x, dy = e.y - player.y;
        if (Math.hypot(dx, dy) > 72) {
            return;
        }
        player.fbar = 0;
        player.finT = .5;
        playSound('finisher');
        burst(e.x, e.y, 34, '#fff');
        screenShake = 9;
        screenFlash = .3;
        flashColor = '255,255,255';
        e.hp = Math.max(0, e.hp - 3);
        e.fl = .15;
        if (e.hp <= 0) {
            awardKill(e, 'fin');
            stageBonus(300, 'DRAGON SLAIN');
            playSound('kill');
            burst(e.x, e.y - 10, 30, '#ff8a4a');
            screenShake = 9;
            screenFlash = .6;
            flashColor = '255,140,70';
            stop = .2;
            enemies = [];
            twist();
        }
        return;
    }
    if (gameState == 'play') {
        if ((player.fbar || 0) < 1) {
            return;
        }
        const rg = 44;
        let best = null, bd = 1e9;
        enemies.forEach(e => {
            if (e.sp > 0) {
                return;
            }
            const dx = e.x - player.x, dy = e.y - player.y, dd = Math.hypot(dx, dy);
            if (dd < rg && dd < bd) {
                bd = dd;
                best = e;
            }
        });
        if (!best) {
            playSound('blip', .4);
            return;
        }
        player.fbar = 0;
        best.dead = 1;
        player.finT = .4;
        playSound('finisher');
        burst(best.x, best.y - 6, 26, '#fff');
        screenShake = 8;
        screenFlash = .25;
        flashColor = '255,255,255';
        enemies = enemies.filter(e => {
            if (e.dead) {
                awardKill(e, 'fin');
                kills++;
                playSound('kill');
                return false;
            }
            return true;
        });
        return;
    }
    if (gameState == 'act2') {
        if ((player.finCd || 0) > 0) {
            return;
        }
        const rg = 62;
        let best = null, bd = 1e9;
        enemies.forEach(e => {
            if (e.t == 'D' || e.sp > 0) {
                return;
            }
            const dx = e.x - player.x, dy = e.y - player.y, dd = Math.hypot(dx, dy);
            if (dd < rg && e.hp <= 2 && dd < bd) {
                bd = dd;
                best = e;
            }
        });
        if (!best) {
            playSound('blip', .4);
            return;
        }
        best.dead = 1;
        player.finCd = 1.1;
        player.finT = .5;
        playSound('finisher');
        burst(best.x, best.y - 6, 26, '#ff6a3d');
        screenShake = 8;
        screenFlash = .25;
        flashColor = '255,110,60';
        enemies = enemies.filter(e => {
            if (e.dead) {
                awardKill(e, 'fin');
                kills++;
                playSound('kill');
                player.charge = clamp((player.charge || 0) + .12, 0, 1);
                return false;
            }
            return true;
        });
    }
}
function a2(d) {
    const spd = clamp(95 - a1t * .45, 48, 82);
    player.charge = clamp((player.charge || 0) + d * 0.045, 0, 1);
    if (player.ultT > 0) {
        player.ultT -= d;
        if (player.ultT <= 0) {
            playSound('boom');
            screenShake = 9;
            screenFlash = .6;
            flashColor = '255,140,60';
            burst(player.utx, player.uty - 8, 30, '#ff8a4a');
            enemies.forEach(e => {
                if (e.sp <= 0 && Math.hypot(e.x - player.utx, e.y - player.uty) < 72) {
                    e.dead = 1;
                }
            });
            enemies = enemies.filter(e => {
                if (e.dead) {
                    awardKill(e);
                    kills++;
                    playSound('kill');
                    burst(e.x, e.y - 6, 10, '#8a5cf0');
                    return false;
                }
                return true;
            });
        }
    }
    enemies.forEach(e => {
        if (e.sp > 0) {
            e.sp -= d;
            if (e.sp <= 0) {
                burst(e.x, e.y - 4, 8, '#fff');
            }
            return;
        }
        e.fl -= d;
        const dx = player.x - e.x, dy = player.y - e.y, dist = Math.hypot(dx, dy) || 1;
        let tx = player.x, ty = player.y, s = spd;
        if (dist > 85) {
            e.i += 1.6;
            const r = rec[(e.i | 0) % rec.length] || [160, 140];
            tx = r[0];
            ty = r[1];
            s = spd * .8;
        }
        const ex = tx - e.x, ey = ty - e.y, l = Math.hypot(ex, ey) || 1;
        e.vx = ex / l * s;
        e.vy = ey / l * s;
        e.x = clamp(e.x + (e.vx + e.kx) * d, 8, 312);
        e.y = clamp(e.y + (e.vy + e.ky) * d, 60, 174);
        e.kx *= .88;
        e.ky *= .88;
        if (dist < 10 && player.inv <= 0) {
            hurt(e);
        }
    });
    if (nw > 0) {
        nw -= d;
        if (nw <= 0) {
            spawnG(wave + 2);
        }
    }
    else if (!enemies.length) {
        wave++;
        if (wave >= 3) {
            finale();
        }
        else {
            nw = 1.6;
            playSound('clear');
            queueLine(wave == 1 ? 'They keep coming. Just as you once did.' : 'One more wave, brave dragon.', 0, 1);
        }
    }
}
// Ends the game and shows the final score screen.
function finale() {
    finalize();
    endT = 0;
    gameState = 'end';
    enemies = [];
    narrationQueue = [];
    narration = {};
    palette = PALETTE_DUNGEON;
    background = BACKGROUNDS[0];
    setMusic(0);
    screenFlash = .8;
    flashColor = '255,240,200';
    [['And so the dragon defeated the last of the knights.', 0, 1.5], ['The princess and her dragon lived happily ever after.', 0, 1.6], ['The End.', 0, 1.4], ['...Or so I would like you to believe.', 1, 1.6], ['Did you never ask who sent the knight up the tower?', 1, 1.8], ['The crown was never hers. It was always meant to be mine.', 1, 2], ['I needed a hero to do my breaking. You did it beautifully.', 1, 2.2]].forEach(a => queueLine(...a));
}
// Runs one 1/60 second step of the game.
function upd(d) {
    time += d;
    uiUpd(d);
    if (deathState.on) {
        updateDeathScreen(d);
        return;
    }
    if (paused) {
        return;
    }
    if (stop > 0) {
        stop -= d;
        return;
    }
    narr(d);
    screenShake *= .9;
    screenFlash *= .92;
    if (gameState == 'title' || gameState == 'settings' || gameState == 'intro') {
        return;
    }
    if (gameState != 'end') {
        scareT -= d;
        if (scareT <= 0) {
            scareT = 9 + rand() * 7;
            playSound(rand() < .5 ? 'screech' : 'growl');
            screenShake = Math.max(screenShake, 2);
        }
        dripT -= d;
        if (dripT <= 0) {
            dripT = 3 + rand() * 5;
            playSound('drip');
        }
        if (player && player.hp <= 2) {
            hbT -= d;
            if (hbT <= 0) {
                hbT = .85;
                playSound('thump');
            }
        }
    }
    if (gameState != 'play') {
        const sprint = isHeld('sprint') && gameState == 'act2', mspd = sprint ? 96 : 62;
        const mx0 = (isHeld('right') ? 1 : 0) - (isHeld('left') ? 1 : 0), my0 = (isHeld('down') ? 1 : 0) - (isHeld('up') ? 1 : 0), l = Math.hypot(mx0, my0);
        player.mv = l;
        if (l) {
            const mx = mx0 / l, my = my0 / l;
            player.ax = mx;
            player.ay = my;
            if (Math.abs(mx) > .1) {
                player.f = Math.sign(mx);
            }
            player.w += d;
            player.x += mx * mspd * d;
            player.y += my * mspd * d;
            if ((player.st -= d) <= 0) {
                player.st = sprint ? .16 : .26;
                playSound(sprint ? 'sprint' : 'step', sprint ? .6 : 1);
                particles.push({ x: player.x, y: player.y, vx: 0, vy: -8, l: .3, c: 'rgba(255,255,255,.35)' });
            }
        }
        player.x = clamp(player.x, 10, 310);
        player.y = clamp(player.y, 62, 172);
        player.inv -= d;
        player.cd -= d;
        player.at -= d;
        player.finCd = Math.max(0, (player.finCd || 0) - d);
        player.finT = Math.max(0, (player.finT || 0) - d);
        const introLock = gameState == 'boss' && enemies[0] && enemies[0].mode == 'intro';
        if ((isAttackHeld() || keysDown.M) && player.cd <= 0 && gameState != 'end' && !introLock) {
            attack();
        }
    }
    else {
        const sprint = isHeld('sprint'), left = isHeld('left'), right = isHeld('right'), jump = isHeld('jump') || isHeld('up'), sspd = sprint && player.onGround ? 168 : 110;
        player.vx = right ? sspd : left ? -sspd : 0;
        if (player.vx) {
            player.f = Math.sign(player.vx);
        }
        player.ax = player.f;
        player.ay = 0;
        player.mv = player.vx ? 1 : 0;
        if (sprint && player.onGround && Math.abs(player.vx) > 5) {
            if ((player.st -= d) <= 0) {
                player.st = .17;
                playSound('sprint', .5);
                particles.push({ x: player.x, y: player.y, vx: 0, vy: -8, l: .25, c: 'rgba(255,255,255,.3)' });
            }
        }
        if (jump && player.onGround) {
            player.vy = -255;
            player.onGround = 0;
            playSound('step');
        }
        player.vy = Math.min(player.vy + 740 * d, 430);
        player.x = clamp(player.x + player.vx * d, 10, LEVEL_W - 10);
        player.y += player.vy * d;
        const seg = segAt(player.x);
        if (seg && player.vy >= 0 && player.y >= seg.y) {
            player.y = seg.y;
            player.vy = 0;
            player.onGround = 1;
        }
        else {
            player.onGround = 0;
            if (!seg && player.y > GAME_H + 40) {
                player.hp--;
                playSound('hurt');
                screenFlash = .35;
                flashColor = '255,60,80';
                screenShake = 5;
                const back = [...T].reverse().find(s => s.x1 <= player.x) || T[0];
                player.x = back.x1 - 16;
                player.y = back.y;
                player.vy = 0;
                player.onGround = 1;
                if (player.hp <= 0) {
                    playerDied();
                }
            }
        }
        player.w += Math.abs(player.vx) * d * .15;
        player.inv -= d;
        player.cd -= d;
        player.at -= d;
        player.finCd = Math.max(0, (player.finCd || 0) - d);
        player.finT = Math.max(0, (player.finT || 0) - d);
        player.fbar = clamp((player.fbar || 0) + d / 9, 0, 1);
        if ((isPlatformAttackHeld() || keysDown.M) && player.cd <= 0) {
            attack();
        }
        cameraX = clamp(player.x - GAME_W / 2, 0, Math.max(0, LEVEL_W - GAME_W));
        enemies.forEach(e => {
            e.fl -= d;
            if (e.t == 'imp' || e.t == 'crawl') {
                const sp = e.t == 'crawl' ? 48 : 26;
                e.x += e.dir * sp * d;
                if (e.x < e.x0) {
                    e.x = e.x0;
                    e.dir = 1;
                }
                if (e.x > e.x1) {
                    e.x = e.x1;
                    e.dir = -1;
                }
            }
            else {
                const sp = e.t == 'float' ? 14 : 22, amp = e.t == 'float' ? 14 : 9;
                e.ph += d;
                e.x += e.dir * sp * d;
                if (e.x < e.x0) {
                    e.x = e.x0;
                    e.dir = 1;
                }
                if (e.x > e.x1) {
                    e.x = e.x1;
                    e.dir = -1;
                }
                e.y = e.baseY + Math.sin(e.ph * 2) * amp;
            }
            const dx = player.x - e.x, dy = (player.y - 8) - (e.y - 5), dist = Math.hypot(dx, dy);
            if (dist < 11 && player.inv <= 0) {
                if (player.vy > 0 && player.y - 14 < e.y) {
                    e.hp = 0;
                    e.dead = 1;
                    playSound('kill');
                    burst(e.x, e.y - 6, 12, '#fff');
                    player.vy = -200;
                    screenShake = 3;
                    awardKill(e, 'stomp');
                    kills++;
                    player.fbar = clamp((player.fbar || 0) + .3, 0, 1);
                }
                else {
                    hurt(e);
                }
            }
        });
        enemies = enemies.filter(e => !e.dead);
        if (!card && player.x > DOOR.x - 10) {
            if (level == 1) {
                stageBonus(100, 'LEVEL CLEAR');
                loadLvl(2);
                player.x = 40;
                player.y = 150;
                player.vy = 0;
                player.onGround = 1;
                cameraX = 0;
                screenFlash = .4;
                flashColor = '150,170,255';
                screenShake = 4;
                saveStageSnapshot();
                showBanner('LEVEL 2', 'The tunnels grow colder');
                queueLine('The tunnels grow colder. Something else stirs here.', 0, 1.8);
            }
            else {
                stageBonus(150, 'LEVEL CLEAR');
                boss();
            }
        }
    }
    if (gameState == 'twist') {
        gi += 1.4;
    }
    else if (gameState == 'act2') {
        a2(d);
    }
    else if (gameState == 'end') {
    }
    else if (gameState == 'boss') {
        enemies.forEach(e => {
            e.fl -= d;
            const dx = player.x - e.x, dy = player.y - e.y, dist = Math.hypot(dx, dy) || 1;
            e.mt -= d;
            if (e.mode == 'intro') {
                e.vx = Math.cos(time * 1.1) * 9;
                e.vy = Math.sin(time * 1.4) * 5;
                e.x = clamp(e.x + e.vx * d, 24, 296);
                e.y = clamp(e.y + e.vy * d, 66, 166);
                if (narrationQueue.length == 0 && !narration.cur) {
                    e.mode = 'idle';
                    e.mt = 1.3;
                }
                return;
            }
            player.fbar = clamp((player.fbar || 0) + d / 7, 0, 1);
            if (e.mode == 'idle') {
                e.vx = Math.cos(time * 1.1) * 28;
                e.vy = Math.sin(time * 1.1) * 20;
                e.chg = clamp(1 - e.mt / 1.6, 0, 1);
                if (e.mt <= 0) {
                    if (rand() < .45) {
                        e.mode = 'tele';
                        e.mt = .55;
                    }
                    else {
                        e.mode = 'charge';
                        e.mt = .9;
                        playSound('telegraph');
                    }
                }
            }
            else if (e.mode == 'tele') {
                e.vx *= .8;
                e.vy *= .8;
                screenFlash = Math.max(screenFlash, .06);
                if (e.mt <= 0) {
                    e.ang = Math.atan2(dy, dx);
                    e.vx = Math.cos(e.ang) * 78;
                    e.vy = Math.sin(e.ang) * 78;
                    e.mode = 'dash';
                    e.mt = .55;
                    playSound('fire');
                }
            }
            else if (e.mode == 'dash') {
                if (e.mt <= 0) {
                    e.mode = 'idle';
                    e.mt = 1.6;
                    e.vx *= .3;
                    e.vy *= .3;
                    e.chg = 0;
                }
            }
            else if (e.mode == 'charge') {
                e.chg = 1;
                e.vx *= .9;
                e.vy *= .9;
                screenFlash = Math.max(screenFlash, Math.sin(time * 18) * .12 + .08);
                if (e.mt <= 0) {
                    e.tgx = player.x;
                    e.tgy = player.y;
                    e.mode = 'telegraph';
                    e.mt = .6;
                    playSound('telegraph');
                }
            }
            else if (e.mode == 'telegraph') {
                e.vx *= .9;
                e.vy *= .9;
                if (e.mt <= 0) {
                    e.mode = 'detonate';
                    e.mt = .12;
                    playSound('boom');
                    screenShake = 9;
                    screenFlash = .6;
                    flashColor = '255,90,40';
                    const ddx = player.x - e.tgx, ddy = player.y - e.tgy;
                    if (Math.hypot(ddx, ddy) < 32 && player.inv <= 0) {
                        player.hp = Math.max(0, player.hp - 3);
                        player.inv = 1.5;
                        playSound('hurt');
                        burst(player.x, player.y - 6, 28, '#ff5d73');
                        if (player.hp <= 0) {
                            playerDied();
                        }
                    }
                }
            }
            else if (e.mode == 'detonate') {
                if (e.mt <= 0) {
                    e.mode = 'idle';
                    e.mt = 1.8;
                    e.chg = 0;
                }
            }
            e.x = clamp(e.x + (e.vx + e.kx) * d, 24, 296);
            e.y = clamp(e.y + (e.vy + e.ky) * d, 66, 166);
            e.kx *= .85;
            e.ky *= .85;
            const hitR = e.mode == 'dash' ? 15 : 12;
            if (dist < hitR && player.inv <= 0) {
                hurt(e);
            }
        });
    }
    else if (gameState == 'play') {
    }
    particles.forEach(o => {
        o.x += o.vx * d;
        o.y += o.vy * d;
        o.vy += 200 * d;
        o.l -= d;
    });
    particles = particles.filter(o => o.l > 0);
}
// ---------- drawing ----------
// Draws a sprite with its feet at (x, y). A negative facing mirrors it.
function drawSprite(c, x, y, f, a, s) {
    s = s || 1;
    gameCtx.globalAlpha = a == null ? 1 : a;
    gameCtx.save();
    gameCtx.translate(Math.round(x), Math.round(y - c.height * s));
    gameCtx.scale((f < 0 ? -1 : 1) * s, s);
    gameCtx.drawImage(c, -c.width / 2, 0);
    gameCtx.restore();
    gameCtx.globalAlpha = 1;
}
// Draws a soft shadow under a character.
function shadow(x, y, r) {
    gameCtx.fillStyle = 'rgba(0,0,0,.4)';
    gameCtx.beginPath();
    gameCtx.ellipse(Math.round(x), Math.round(y), r, r * .4, 0, 0, TAU);
    gameCtx.fill();
}
// Draws a wall torch and its flicker.
function torch(x, y) {
    gameCtx.fillStyle = '#4a3b2a';
    gameCtx.fillRect(x - 1, y, 3, 7);
    gameCtx.fillStyle = '#2a2018';
    gameCtx.fillRect(x - 3, y + 6, 7, 2);
    const f = Math.round(Math.sin(time * 20 + x));
    gameCtx.fillStyle = palette.fl;
    gameCtx.fillRect(x - 2, y - 5 - f, 5, 5);
    gameCtx.fillStyle = '#ffe9a8';
    gameCtx.fillRect(x - 1, y - 4 - f, 3, 3);
}
// Draws additive light glows at the given spots.
function glowAt(lts) {
    lts.forEach(([x, y, r, a, c]) => {
        const gr = gameCtx.createRadialGradient(x, y, 0, x, y, r);
        gr.addColorStop(0, `rgba(${c},${a * .2})`);
        gr.addColorStop(1, `rgba(${c},0)`);
        gameCtx.fillStyle = gr;
        gameCtx.fillRect(x - r, y - r, r * 2, r * 2);
    });
}
// Draws the game world onto the small pixel canvas.
function draw() {
    if (gameState == 'title' || gameState == 'settings') {
        drawMenuBg();
        return;
    }
    if (gameState == 'intro') {
        return;
    }
    gameCtx.save();
    if (screenShake > .3 && settings.shake) {
        gameCtx.translate((rand() - .5) * screenShake, (rand() - .5) * screenShake);
    }
    if (gameState == 'play') {
        gameCtx.fillStyle = palette.wall;
        gameCtx.fillRect(0, 0, GAME_W, GAME_H);
        const vx0 = cameraX - 20, vx1 = cameraX + GAME_W + 20;
        gameCtx.save();
        gameCtx.translate(-cameraX, 0);
        gameCtx.fillStyle = palette.brick;
        for (let wx = Math.floor(vx0 / 16) * 16; wx < vx1; wx += 16) {
            for (let y = 0; y < 40; y += 8) {
                gameCtx.fillRect(wx + ((y / 8) % 2 ? 8 : 0), y, 15, 7);
            }
        }
        gameCtx.fillStyle = 'rgba(0,0,0,.3)';
        gameCtx.fillRect(vx0, 40, vx1 - vx0, 4);
        const torchXs = [];
        for (let tx = Math.floor(vx0 / 140) * 140; tx < vx1; tx += 140) {
            torchXs.push(tx);
            torch(tx, 40);
        }
        DEC.forEach(d => {
            if (d.x < vx0 - 20 || d.x > vx1 + 20) {
                return;
            }
            if (d.t == 'chain') {
                let cy = 0;
                for (let i = 0; i < 9; i++) {
                    gameCtx.fillStyle = i % 2 ? '#3a3556' : '#0c0a1c';
                    gameCtx.fillRect(d.x + (i % 2 ? 1 : 0), cy, 2, 3);
                    cy += 4;
                }
                gameCtx.fillStyle = '#1a1730';
                gameCtx.fillRect(d.x - 1, cy, 4, 3);
            }
            else if (d.t == 'web') {
                gameCtx.strokeStyle = 'rgba(220,224,240,.3)';
                gameCtx.lineWidth = 1;
                gameCtx.beginPath();
                for (let a = 0; a < 4; a++) {
                    gameCtx.moveTo(d.x, d.y);
                    gameCtx.lineTo(d.x + d.dir * (10 + a * 3), d.y + 6 + a * 2);
                }
                gameCtx.stroke();
            }
            else if (d.t == 'eyes') {
                const bl = Math.max(0, Math.sin(time * 1.3 + d.ph)) * Math.max(0, Math.sin(time * .37 + d.ph * 2));
                if (bl > .55) {
                    const al = (bl - .55) * 2.2;
                    gameCtx.fillStyle = `rgba(255,150,60,${al})`;
                    gameCtx.fillRect(d.x - 2, d.y, 1, 1);
                    gameCtx.fillRect(d.x + 2, d.y, 1, 1);
                }
            }
        });
        T.forEach(s => {
            if (s.x1 < vx0 || s.x0 > vx1) {
                return;
            }
            gameCtx.fillStyle = '#211a2e';
            gameCtx.fillRect(s.x0, s.y, s.x1 - s.x0, GAME_H - s.y + 30);
            gameCtx.fillStyle = '#4a3f66';
            gameCtx.fillRect(s.x0, s.y, s.x1 - s.x0, 3);
            gameCtx.fillStyle = '#161020';
            for (let cx2 = s.x0 + 4; cx2 < s.x1; cx2 += 14) {
                gameCtx.fillRect(cx2, s.y + 6, 2, GAME_H - s.y);
            }
        });
        DEC.forEach(d => {
            if (d.t != 'bones' || d.x < vx0 - 10 || d.x > vx1 + 10) {
                return;
            }
            gameCtx.fillStyle = 'rgba(205,198,180,.65)';
            gameCtx.fillRect(d.x | 0, d.y - 2, 5, 1);
            gameCtx.fillRect((d.x + 1) | 0, d.y - 4, 1, 3);
            gameCtx.fillRect((d.x - 3) | 0, d.y - 1, 3, 1);
        });
        if (SPRITES.door) {
            drawSprite(SPRITES.door, DOOR.x, DOOR.y, 1);
        }
        const dl = [];
        dl.push([player.y, () => {
                shadow(player.x, player.y, 5);
                if (deathState.on || player.inv > 0 && (time * 20 | 0) % 2) {
                    return;
                }
                const bob = Math.abs(player.vx) > 5 && player.onGround ? Math.abs(Math.sin(player.w * 10)) * 1.3 : 0;
                drawSprite(SPRITES.k, player.x, player.y - bob, player.f);
                if (player.at > 0) {
                    const pr = 1 - player.at / .18, an = (player.f < 0 ? PI : 0) - 1.1 + pr * 1.6;
                    gameCtx.strokeStyle = `rgba(255,255,255,${1 - pr})`;
                    gameCtx.lineWidth = 3;
                    gameCtx.beginPath();
                    gameCtx.arc(player.x + player.f * 6, player.y - 7, 15, an, an + 1.1);
                    gameCtx.stroke();
                    gameCtx.strokeStyle = `rgba(242,193,78,${1 - pr})`;
                    gameCtx.lineWidth = 1;
                    gameCtx.beginPath();
                    gameCtx.arc(player.x + player.f * 6, player.y - 7, 12, an, an + 1.1);
                    gameCtx.stroke();
                }
            }]);
        enemies.forEach(e => dl.push([e.y, () => {
                shadow(e.x, e.y, e.t == 'bat' || e.t == 'float' ? 4 : 5);
                const k = e.t == 'bat' ? 'b' + (1 + ((e.ph | 0) % 2)) : e.t;
                drawSprite(e.fl > 0 ? WHITE_SPRITES[k] : SPRITES[k], e.x, e.y, e.dir < 0 ? -1 : 1);
            }]));
        dl.sort((a, b) => a[0] - b[0]).forEach(o => o[1]());
        particles.forEach(o => {
            gameCtx.globalAlpha = Math.min(1, o.l * 3);
            gameCtx.fillStyle = o.c;
            gameCtx.fillRect(o.x | 0, o.y | 0, 2, 2);
        });
        gameCtx.globalAlpha = 1;
        gameCtx.restore();
        const fl = 1 + Math.sin(time * 13) * .05 + Math.sin(time * 7.3) * .05, lts = torchXs.map(tx => [tx - cameraX, 40, 85 * fl, .82, palette.gl]);
        lts.push([player.x - cameraX, player.y - 8, 58, .9, palette.gl]);
        lightCtx.globalCompositeOperation = 'source-over';
        lightCtx.fillStyle = palette.dark;
        lightCtx.fillRect(0, 0, GAME_W, GAME_H);
        lightCtx.globalCompositeOperation = 'destination-out';
        lts.forEach(([x, y, r, a]) => {
            const gr = lightCtx.createRadialGradient(x, y, 0, x, y, r);
            gr.addColorStop(0, `rgba(0,0,0,${a})`);
            gr.addColorStop(1, 'rgba(0,0,0,0)');
            lightCtx.fillStyle = gr;
            lightCtx.fillRect(x - r, y - r, r * 2, r * 2);
        });
        gameCtx.drawImage(lightCanvas, 0, 0);
        gameCtx.globalCompositeOperation = 'lighter';
        glowAt(lts);
        gameCtx.globalCompositeOperation = 'source-over';
        gameCtx.fillStyle = `rgba(${palette.fog},.35)`;
        MO.forEach(m => {
            const sx = ((m.x + time * m.s - cameraX * .4) % GAME_W + GAME_W) % GAME_W;
            gameCtx.fillRect(sx | 0, (m.y + Math.sin(time + m.ph) * 6) | 0, 1, 1);
        });
        if (screenFlash > .02) {
            gameCtx.fillStyle = `rgba(${flashColor},${screenFlash})`;
            gameCtx.fillRect(0, 0, GAME_W, GAME_H);
        }
        gameCtx.restore();
        return;
    }
    gameCtx.drawImage(background, 0, 0);
    torch(50, 42);
    torch(270, 42);
    const dl = [];
    if (gameState == 'act2' || gameState == 'end') {
        dl.push([60, () => {
                shadow(160, 60, 6);
                drawSprite(SPRITES.pr, 160, 60 - Math.sin(time * 2) * .5, 1);
            }]);
    }
    dl.push([player.y, () => {
            const isD = gameState == 'act2' || gameState == 'end';
            shadow(player.x, player.y, isD ? 6 : 5);
            if (deathState.on || player.inv > 0 && (time * 20 | 0) % 2) {
                return;
            }
            const bob = player.mv ? Math.abs(Math.sin(player.w * 12)) * 1.5 : Math.sin(time * 3) * .4;
            drawSprite(isD ? SPRITES.dr : SPRITES.k, player.x, player.y - bob, player.f, null, 1);
            if (player.at > 0 && gameState == 'twist') {
                const pr = 1 - player.at / .16, an = Math.atan2(player.ay, player.ax) - 1.1 + pr * 1.6;
                gameCtx.strokeStyle = `rgba(255,255,255,${1 - pr})`;
                gameCtx.lineWidth = 3;
                gameCtx.beginPath();
                gameCtx.arc(player.x + player.ax * 6, player.y - 7 + player.ay * 6, 15, an, an + 1.1);
                gameCtx.stroke();
                gameCtx.strokeStyle = `rgba(242,193,78,${1 - pr})`;
                gameCtx.lineWidth = 1;
                gameCtx.beginPath();
                gameCtx.arc(player.x + player.ax * 6, player.y - 7 + player.ay * 6, 12, an, an + 1.1);
                gameCtx.stroke();
            }
            if (player.finT > 0) {
                const fp = player.finT / (isD ? .5 : .4);
                if (isD) {
                    gameCtx.strokeStyle = `rgba(255,130,60,${fp * .9})`;
                    gameCtx.lineWidth = 2;
                    gameCtx.beginPath();
                    gameCtx.arc(player.x, player.y - 6, 24 * (1 - fp) + 8, 0, TAU);
                    gameCtx.stroke();
                    gameCtx.strokeStyle = `rgba(255,220,160,${fp * .6})`;
                    gameCtx.beginPath();
                    gameCtx.arc(player.x, player.y - 6, 30 * (1 - fp) + 4, 0, TAU);
                    gameCtx.stroke();
                }
                else {
                    for (let i = 0; i < 3; i++) {
                        const a = time * 30 + i * 2.1;
                        gameCtx.strokeStyle = `rgba(255,255,255,${fp * .8})`;
                        gameCtx.lineWidth = 2;
                        gameCtx.beginPath();
                        gameCtx.arc(player.x, player.y - 7, 13, a, a + 1.3);
                        gameCtx.stroke();
                    }
                }
            }
        }]);
    if (player.ultT > 0) {
        dl.push([player.uty + 40, () => {
                const fp = 1 - player.ultT / .55, rad = 20 + fp * 55;
                gameCtx.strokeStyle = `rgba(255,${200 - fp * 120 | 0},80,${(1 - fp) * .9})`;
                gameCtx.lineWidth = 2;
                gameCtx.beginPath();
                gameCtx.arc(player.utx, player.uty, rad, 0, TAU);
                gameCtx.stroke();
                gameCtx.fillStyle = `rgba(255,160,60,${(1 - fp) * .12})`;
                gameCtx.beginPath();
                gameCtx.arc(player.utx, player.uty, rad, 0, TAU);
                gameCtx.fill();
            }]);
    }
    enemies.forEach(e => dl.push([e.y, () => {
            if (e.sp > 0) {
                gameCtx.strokeStyle = 'rgba(255,255,255,.6)';
                gameCtx.lineWidth = 1;
                gameCtx.beginPath();
                gameCtx.ellipse(e.x | 0, e.y | 0, e.sp * 14, e.sp * 6, 0, 0, TAU);
                gameCtx.stroke();
                return;
            }
            if (e.t == 'D') {
                shadow(e.x, e.y, 9);
                drawSprite(e.fl > 0 ? WHITE_SPRITES.dr : SPRITES.dr, e.x, e.y - e.hz, e.vx < 0 ? -1 : 1, null, 1);
                if (e.mode == 'charge') {
                    const pulse = 2 + Math.sin(time * 16) * 1.5;
                    gameCtx.strokeStyle = `rgba(255,160,60,.8)`;
                    gameCtx.lineWidth = 2;
                    gameCtx.beginPath();
                    gameCtx.arc(e.x, e.y, 13 + pulse, 0, TAU);
                    gameCtx.stroke();
                }
                if (e.mode == 'telegraph') {
                    const fp = 1 - e.mt / .6, rad = 18 + fp * 18;
                    gameCtx.strokeStyle = `rgba(255,${80 - fp * 40 | 0},40,${.5 + Math.sin(time * 20) * .3})`;
                    gameCtx.lineWidth = 2;
                    gameCtx.beginPath();
                    gameCtx.arc(e.tgx, e.tgy, rad, 0, TAU);
                    gameCtx.stroke();
                    gameCtx.fillStyle = `rgba(255,60,30,${.1 + fp * .15})`;
                    gameCtx.beginPath();
                    gameCtx.arc(e.tgx, e.tgy, rad, 0, TAU);
                    gameCtx.fill();
                }
                return;
            }
            shadow(e.x, e.y, e.t == 's' ? 6 : 4);
            const k = e.t == 's' ? 's' : e.t == 'g' ? 'gh' : 'b' + (1 + ((e.ph | 0) % 2));
            drawSprite(e.fl > 0 ? WHITE_SPRITES[k] : SPRITES[k], e.x, e.y - e.hz, e.vx < 0 ? -1 : 1);
        }]));
    if (gameState == 'twist' && rec.length) {
        [16, 8, 0].forEach((o, i) => {
            const r = rec[Math.max(0, (gi | 0) - o) % rec.length];
            dl.push([r[1] - .1, () => drawSprite(SPRITES.gh, r[0], r[1], r[2], [.12, .25, .6][i])]);
        });
    }
    dl.sort((a, b) => a[0] - b[0]).forEach(o => o[1]());
    particles.forEach(o => {
        gameCtx.globalAlpha = Math.min(1, o.l * 3);
        gameCtx.fillStyle = o.c;
        gameCtx.fillRect(o.x | 0, o.y | 0, 2, 2);
    });
    gameCtx.globalAlpha = 1;
    // lighting
    const fl = 1 + Math.sin(time * 13) * .05 + Math.sin(time * 7.3) * .05 + Math.sin(time * 31) * .03, lts = [[50, 44, 95 * fl, .85, palette.gl], [270, 44, 95 * fl, .85, palette.gl], [160, 50, 120, .5, gameState == 'twist' ? '255,90,70' : '150,170,255'], [player.x, player.y - 8, 58, .9, palette.gl]];
    lightCtx.globalCompositeOperation = 'source-over';
    lightCtx.fillStyle = palette.dark;
    lightCtx.fillRect(0, 0, GAME_W, GAME_H);
    lightCtx.globalCompositeOperation = 'destination-out';
    lts.forEach(([x, y, r, a]) => {
        const gr = lightCtx.createRadialGradient(x, y, 0, x, y, r);
        gr.addColorStop(0, `rgba(0,0,0,${a})`);
        gr.addColorStop(1, 'rgba(0,0,0,0)');
        lightCtx.fillStyle = gr;
        lightCtx.fillRect(x - r, y - r, r * 2, r * 2);
    });
    gameCtx.drawImage(lightCanvas, 0, 0);
    gameCtx.globalCompositeOperation = 'lighter';
    glowAt(lts);
    gameCtx.fillStyle = `rgba(${palette.fog},.4)`;
    MO.forEach(m => gameCtx.fillRect((m.x + time * m.s) % GAME_W | 0, m.y + Math.sin(time + m.ph) * 6 | 0, 1, 1));
    gameCtx.globalCompositeOperation = 'source-over';
    if (screenFlash > .02) {
        gameCtx.fillStyle = `rgba(${flashColor},${screenFlash})`;
        gameCtx.fillRect(0, 0, GAME_W, GAME_H);
    }
    gameCtx.restore();
}
// Draws one heart icon (full or empty).
function mask(x, y, s, full) {
    uiCtx.save();
    uiCtx.translate(x, y);
    uiCtx.beginPath();
    uiCtx.moveTo(0, -s);
    uiCtx.lineTo(s * .82, 0);
    uiCtx.lineTo(0, s);
    uiCtx.lineTo(-s * .82, 0);
    uiCtx.closePath();
    if (full) {
        uiCtx.fillStyle = '#eceee4';
        uiCtx.fill();
        uiCtx.strokeStyle = '#14132a';
        uiCtx.lineWidth = 1.4;
        uiCtx.stroke();
        uiCtx.strokeStyle = 'rgba(20,19,42,.35)';
        uiCtx.lineWidth = 1;
        uiCtx.beginPath();
        uiCtx.moveTo(-s * .25, -s * .35);
        uiCtx.lineTo(s * .12, s * .1);
        uiCtx.lineTo(-s * .08, s * .5);
        uiCtx.stroke();
    }
    else {
        uiCtx.strokeStyle = 'rgba(238,240,230,.3)';
        uiCtx.lineWidth = 1.4;
        uiCtx.stroke();
    }
    uiCtx.restore();
}
// Draws a horizontal progress bar.
function bar(x, y, w, h, frac, col, flash2) {
    uiCtx.fillStyle = 'rgba(8,5,16,.7)';
    uiCtx.fillRect(x, y, w, h);
    uiCtx.fillStyle = flash2 ? `rgba(255,240,140,${.7 + Math.sin(time * 20) * .3})` : col;
    uiCtx.fillRect(x, y, w * clamp(frac, 0, 1), h);
    uiCtx.strokeStyle = 'rgba(244,234,210,.5)';
    uiCtx.lineWidth = 1;
    uiCtx.strokeRect(x + .5, y + .5, w - 1, h - 1);
}
// Film grain overlay.
function grain() {
    for (let i = 0; i < 36; i++) {
        uiCtx.fillStyle = `rgba(255,255,255,${rand() * .04})`;
        uiCtx.fillRect(rand() * 960 | 0, rand() * 540 | 0, 1, 1);
    }
}
// Darkens the screen edges.
function vignette() {
    const vg = uiCtx.createRadialGradient(480, 270, 180, 480, 270, 560);
    vg.addColorStop(0, 'rgba(0,0,0,0)');
    vg.addColorStop(1, 'rgba(4,2,10,.6)');
    uiCtx.fillStyle = vg;
    uiCtx.fillRect(0, 0, 960, 540);
}
// Splits text into lines that fit a given pixel width.
function wrap(t, w) {
    let l = '', o = [];
    t.split(' ').forEach(x => {
        if (uiCtx.measureText(l + x).width > w && l) {
            o.push(l);
            l = '';
        }
        l += x + ' ';
    });
    o.push(l);
    return o;
}
const fontOf = (s, st2) => `${st2 || 'italic'} ${s}px Georgia,'Times New Roman',serif`;
// Draws hearts, score, text boxes and menus onto the big canvas.
function drawUI() {
    uiCtx.clearRect(0, 0, 960, 540);
    buttons.length = 0;
    uiCtx.textAlign = 'center';
    if (drawMenus()) {
        if (gameState != 'intro') {
            grain();
            vignette();
        }
        fadeRect();
        return;
    }
    if (gameState == 'act2') {
        uiCtx.textAlign = 'left';
        uiCtx.fillStyle = 'rgba(244,234,210,.75)';
        uiCtx.font = fontOf(13, 'normal');
        uiCtx.fillText('HP', 30, 24);
        bar(30, 28, 210, 13, player.hp / (player.mh || 8), '#ff5d73');
        uiCtx.fillText('CHARGE' + (touchMode ? '' : '  (' + firstKeyName('ultimate') + ')'), 30, 52);
        bar(30, 56, 210, 8, player.charge || 0, '#ffce54', (player.charge || 0) >= 1);
    }
    else {
        for (let i = 0; i < (player.mh || 5); i++) {
            mask(40 + i * 26, 28, 11, i < player.hp);
        }
        uiCtx.textAlign = 'left';
        uiCtx.fillStyle = 'rgba(244,234,210,.65)';
        uiCtx.font = fontOf(11, 'normal');
        uiCtx.fillText('FINISH' + (touchMode ? '' : ' (' + firstKeyName('finish') + ')'), 30, 52);
        bar(30, 55, 160, 7, player.fbar || 0, '#9fe8c8', (player.fbar || 0) >= 1);
    }
    if (gameState == 'boss' && enemies[0]) {
        uiCtx.textAlign = 'center';
        uiCtx.fillStyle = 'rgba(244,234,210,.85)';
        uiCtx.font = fontOf(16, 'normal');
        uiCtx.fillText('THE DRAGON', 480, 34);
        bar(330, 40, 300, 11, enemies[0].hp / BOSS_MAXHP, '#ff5d73');
        bar(330, 54, 300, 7, enemies[0].chg || 0, '#ff8a3d', enemies[0].mode == 'telegraph');
    }
    uiCtx.textAlign = 'right';
    uiCtx.fillStyle = 'rgba(244,234,210,.7)';
    uiCtx.font = fontOf(22);
    if (gameState == 'act2') {
        uiCtx.fillText(`Wave ${Math.min(wave + 1, 3)} of 3`, 924, 42);
    }
    if (gameState == 'play') {
        uiCtx.fillText(`Level ${level} of 2`, 924, 42);
    }
    uiCtx.textAlign = 'center';
    const ht = time - t0;
    if (ht < 9 && (gameState == 'play' || gameState == 'act2')) {
        uiCtx.globalAlpha = Math.min(1, (9 - ht) / 2);
        uiCtx.fillStyle = 'rgba(244,234,210,.85)';
        uiCtx.font = fontOf(18);
        uiCtx.fillText(hintText(), 480, 90);
        uiCtx.globalAlpha = 1;
    }
    if (narration.cur) {
        const c = narration.cur, gl = c.g;
        uiCtx.save();
        if (gl && rand() < .3) {
            uiCtx.translate((rand() - .5) * 8, (rand() - .5) * 4);
        }
        uiCtx.fillStyle = 'rgba(10,6,28,.85)';
        uiCtx.strokeStyle = palette.acc;
        uiCtx.lineWidth = 2;
        uiCtx.beginPath();
        uiCtx.roundRect(90, 424, touchMode ? 560 : 780, 96, 10);
        uiCtx.fill();
        uiCtx.stroke();
        uiCtx.textAlign = 'left';
        uiCtx.fillStyle = c.spk == 'The Dragon' ? '#ff8a5c' : c.spk == 'The Knight' ? '#9fc4ff' : palette.acc;
        uiCtx.font = fontOf(16);
        uiCtx.fillText(c.spk || 'The Narrator', 116, 452);
        uiCtx.font = fontOf(26);
        let n = narration.i;
        wrap(c.t, touchMode ? 510 : 730).forEach((ln, j) => {
            let s = ln.slice(0, Math.max(0, n));
            n -= ln.length;
            if (gl) {
                s = [...s].map(ch => rand() < .06 ? '#%&?'[rand() * 4 | 0] : ch).join('');
            }
            uiCtx.fillStyle = gl && rand() < .15 ? palette.acc : '#f4ead2';
            uiCtx.fillText(s, 116, 486 + j * 30);
        });
        uiCtx.restore();
    }
    if (card == 1) {
        uiCtx.fillStyle = 'rgba(20,3,8,.6)';
        uiCtx.fillRect(0, 0, 960, 540);
        uiCtx.textAlign = 'center';
        uiCtx.shadowColor = 'rgba(255,93,115,.7)';
        uiCtx.shadowBlur = 30;
        uiCtx.fillStyle = palette.acc;
        if (card == 1) {
            uiCtx.font = fontOf(96, 'italic bold');
            uiCtx.fillText('Act II', 480, 250);
            uiCtx.shadowBlur = 0;
            uiCtx.fillStyle = '#f4ead2';
            uiCtx.font = fontOf(36);
            uiCtx.fillText('You are the dragon.', 480, 315);
            uiCtx.fillStyle = 'rgba(244,234,210,.6)';
            uiCtx.font = fontOf(20);
            uiCtx.fillText(touchMode ? 'Tap to continue' : 'Press Space to continue', 480, 420);
        }
    }
    grain();
    vignette();
    drawOverlays();
}
// ---------- input & loop ----------
let last = 0, acc = 0, ready = false;
// Main loop: runs the game logic at a fixed rate, then draws a frame.
function loop(ts) {
    const d = Math.min((ts - last) / 1000, .1);
    last = ts;
    acc += d;
    if (!ready) {
        uiCtx.clearRect(0, 0, 960, 540);
        uiCtx.fillStyle = '#0a0814';
        uiCtx.fillRect(0, 0, 960, 540);
        uiCtx.fillStyle = '#f2c14e';
        uiCtx.font = fontOf(28);
        uiCtx.textAlign = 'center';
        uiCtx.fillText('Loading the tower' + '.'.repeat((ts / 300 | 0) % 4), 480, 270);
        requestAnimationFrame(loop);
        return;
    }
    while (acc >= 1 / 60) {
        upd(1 / 60);
        acc -= 1 / 60;
    }
    draw();
    drawUI();
    requestAnimationFrame(loop);
}
requestAnimationFrame(loop);
loadSettings();
Promise.all([loadSprites(), loadBG(), loadAudio().catch(e => console.warn('audio load failed', e))]).then(() => {
    ready = true;
    run();
    gotoMenu();
});
