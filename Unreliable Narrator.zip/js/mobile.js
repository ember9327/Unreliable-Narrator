// Small fixes so the game works on iPhones and older versions of Safari.

// Older Safari (before version 16) has no roundRect, so this adds a simple version of it.
// The dialogue boxes use it, and without it the game stops at the first box.
if (window.CanvasRenderingContext2D && !CanvasRenderingContext2D.prototype.roundRect) {
    CanvasRenderingContext2D.prototype.roundRect = function (x, y, w, h, r) {
        r = Math.max(0, Math.min(typeof r === 'number' ? r : (r && r[0]) || 0, w / 2, h / 2));
        this.moveTo(x + r, y);
        this.arcTo(x + w, y, x + w, y + h, r);
        this.arcTo(x + w, y + h, x, y + h, r);
        this.arcTo(x, y + h, x, y, r);
        this.arcTo(x, y, x + w, y, r);
        this.closePath();
    };
}

// When a phone is held upright we turn the whole page sideways, so the game stays
// playable even if the player has the rotation lock switched on (common on iPhones).
let sidewaysMode = false;

function isTouchDevice() {
    return (window.matchMedia && matchMedia('(pointer: coarse)').matches) || 'ontouchstart' in window;
}

// Works out whether the page needs to be turned sideways and resizes everything.
function updateLayout() {
    const width = innerWidth;
    const height = innerHeight;
    const body = document.body;
    const game = document.getElementById('w');
    sidewaysMode = isTouchDevice() && height > width && width < 820;
    document.documentElement.classList.toggle('sideways', sidewaysMode);
    if (sidewaysMode) {
        // the body becomes a landscape box (height x width) that is rotated a quarter turn
        body.style.width = height + 'px';
        body.style.height = width + 'px';
        body.style.transform = 'translateX(' + width + 'px) rotate(90deg)';
        const gameWidth = Math.min(height, width * 16 / 9);
        game.style.width = gameWidth + 'px';
        game.style.height = (gameWidth * 9 / 16) + 'px';
    }
    else {
        body.style.width = body.style.height = body.style.transform = '';
        game.style.width = game.style.height = '';
    }
    if (typeof sizeTouchUi === 'function') {
        sizeTouchUi();
    }
}

// Gives the position of a touch or mouse event as if the screen was not rotated.
function getPointer(e) {
    if (sidewaysMode) {
        return { x: e.clientY, y: innerWidth - e.clientX };
    }
    return { x: e.clientX, y: e.clientY };
}

// Gives the game area rectangle in the same (unrotated) coordinates as getPointer.
function getGameRect() {
    const game = document.getElementById('w');
    if (!sidewaysMode) {
        return game.getBoundingClientRect();
    }
    const left = (innerHeight - game.clientWidth) / 2;
    const top = (innerWidth - game.clientHeight) / 2;
    return {
        left: left,
        top: top,
        width: game.clientWidth,
        height: game.clientHeight
    };
}

addEventListener('resize', updateLayout);
addEventListener('orientationchange', () => setTimeout(updateLayout, 200));
addEventListener('load', updateLayout);

// iPhone sound: Safari only lets sound start after a finger is lifted (not when it touches down),
// and the silent switch mutes web audio. Playing a very quiet audio tag fixes the silent switch.
let quietTag = null;
function unlockSound() {
    try {
        if (navigator.audioSession) {
            navigator.audioSession.type = 'playback';
        }
        if (!quietTag) {
            quietTag = document.createElement('audio');
            quietTag.setAttribute('playsinline', '');
            quietTag.loop = true;
            quietTag.volume = 0.01;
            quietTag.src = 'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAESsAABErAAABAAgAZGF0YQAAAAA=';
            const started = quietTag.play();
            if (started && started.catch) {
                started.catch(() => {
                    quietTag = null;
                });
            }
        }
    }
    catch (err) {
    }
    if (typeof startAudio === 'function') {
        startAudio();
    }
}
['touchend', 'pointerup', 'click', 'keydown'].forEach(type => {
    addEventListener(type, unlockSound, { capture: true, passive: true });
});
