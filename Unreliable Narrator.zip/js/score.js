// Score, combos, death screen logic, replay and restart.

// ================= SCORE / COMBO SYSTEM =================
const KILL_POINTS = { imp: 20, bat: 15, crawl: 10, float: 25, g: 30, D: 500, s: 20, b: 15 };
let score = 0, comboBank = 0, combo = 0, comboTimer = 0, bestCombo = 0, bestComboThisLife = 0, deaths = 0, killCount = 0, scoreParts = { kills: 0, bonus: 0, combo: 0, hearts: 0 }, popups = [], shownScore = 0, scoreBump = 0, runStart = 0, runTime = 0, newBest = false;
function resetStats() {
    score = 0;
    comboBank = 0;
    combo = 0;
    comboTimer = 0;
    bestCombo = 0;
    bestComboThisLife = 0;
    deaths = 0;
    killCount = 0;
    scoreParts = { kills: 0, bonus: 0, combo: 0, hearts: 0 };
    popups = [];
    shownScore = 0;
    scoreBump = 0;
    runStart = time;
    newBest = false;
    deathState.on = false;
    paused = false;
    musicDuck = 1;
    applyMusic(.3);
    banner = null;
}
// Gives points for a kill and keeps the combo going.
function awardKill(e, how) {
    let base = KILL_POINTS[e.t] || 10;
    if (how == 'stomp') {
        base += 5;
    }
    if (how == 'fin') {
        base = Math.round(base * 1.5);
    }
    combo = comboTimer > 0 ? combo + 1 : 1;
    comboTimer = 3.2;
    bestComboThisLife = Math.max(bestComboThisLife, combo);
    bestCombo = Math.max(bestCombo, combo);
    const mult = 1 + Math.min(combo - 1, 8) * .25, pts = Math.round(base * mult);
    score += pts;
    scoreParts.kills += pts;
    killCount++;
    scoreBump = 1;
    const col = combo >= 5 ? '#ff5d73' : combo >= 3 ? '#ff8a3d' : '#f2c14e';
    popups.push({ x: e.x, y: e.y - 14, t: 0, l: 1.1, txt: '+' + pts, col, s: combo >= 3 ? 3 : 2 });
    if (combo >= 2) {
        popups.push({ x: e.x, y: e.y - 28, t: 0, l: 1.1, txt: 'X' + combo + ' COMBO', col: '#ffffff', s: 2 });
    }
    if (combo >= 3) {
        playUiSound('coin');
    }
}
function stageBonus(n, label) {
    score += n;
    scoreParts.bonus += n;
    scoreBump = 1;
    popups.push({ x: 160, y: 62, t: 0, l: 1.7, txt: label + ' +' + n, col: '#9fe8c8', s: 2, fixed: 1 });
}
// Adds the heart bonus and checks the best score when the game ends.
function finalize() {
    scoreParts.hearts = Math.max(0, player.hp) * 50;
    score += scoreParts.hearts;
    runTime = time - runStart;
    const tot = score + comboBank;
    if (tot > bestScore) {
        bestScore = tot;
        newBest = true;
        storeSet('un_best', String(bestScore));
    }
}
const rankOf = t => t >= 2300 ? 'S' : t >= 1700 ? 'A' : t >= 1100 ? 'B' : 'C';
// ================= STAGE SNAPSHOT / DEATH / REPLAY =================
let stageSnapshot = { kind: 'play', lvl: 1, hp: 7, mh: 7, fbar: 0, score: 0, kills: 0, sck: 0, scb: 0 };
let deathState = { on: false, t: 0, sel: 0, bonus: 0, best: 0, quip: '', score: 0 }, paused = false, banner = null, fadeA = 0, endT = 0;
const QUIPS = ['That was not in the script.', 'Let us pretend that never happened.', 'Heroes do not die. Edit: they do.', 'I will tell it differently this time.', 'A minor plot hole. Try again.', 'Splendid. Almost.', 'Nobody saw that. Nobody.', 'The story demands a rewrite.'];
const randomItem = a => a[rand() * a.length | 0];
const showBanner = (a, b) => {
    banner = { a, b, t: 0 };
};
const fadeIn = () => {
    fadeA = 1;
};
function saveStageSnapshot() {
    stageSnapshot = { kind: gameState, lvl: level, hp: player.hp, mh: player.mh, fbar: player.fbar || 0, score, kills, sck: scoreParts.kills, scb: scoreParts.bonus };
}
// Called when the player runs out of hearts: shows the death screen and banks the combo bonus.
function playerDied() {
    if (deathState.on) {
        return;
    }
    const b = bestComboThisLife >= 2 ? bestComboThisLife * 25 : 0;
    comboBank += b;
    scoreParts.combo += b;
    deaths++;
    deathState = { on: true, t: 0, sel: 0, bonus: b, best: bestComboThisLife, quip: randomItem(QUIPS), score: score + comboBank, ch: 0 };
    burst(player.x, player.y - 8, 46, '#ff5d73');
    burst(player.x, player.y - 8, 26, '#ffffff');
    screenShake = 12;
    screenFlash = .7;
    flashColor = '255,40,60';
    playSound('stinger');
    playSound('thump');
    playSound('roar', .55, .7);
    musicDuck = .15;
    applyMusic(.3);
    narrationQueue = [];
    narration = {};
    combo = 0;
    comboTimer = 0;
    keysDown.M = 0;
    popups.forEach(f => f.t = f.l);
}
function updateDeathScreen(d) {
    deathState.t += d;
    screenShake *= .9;
    screenFlash *= .92;
    particles.forEach(o => {
        o.x += o.vx * d;
        o.y += o.vy * d;
        o.vy += 200 * d;
        o.l -= d;
    });
    particles = particles.filter(o => o.l > 0);
    if (deathState.t > .9 && !deathState.ch) {
        deathState.ch = 1;
        playUiSound('bad');
    }
}
function startLevel(n, hp) {
    palette = PALETTE_DUNGEON;
    background = BACKGROUNDS[0];
    gameState = 'play';
    card = 0;
    player = { x: 40, y: 150, ax: 1, ay: 0, f: 1, hp: hp, mh: 7, inv: 1, at: 0, cd: 0, w: 0, st: 0, mv: 0, vx: 0, vy: 0, onGround: 1, sprintT: 0, finT: 0, fbar: 0, finCd: 0 };
    cameraX = 0;
    loadLvl(n);
    particles = [];
    wave = 0;
    nw = 0;
    narrationQueue = [];
    narration = {};
    setMusic(0);
    t0 = time;
    screenFlash = 0;
    screenShake = 0;
}
// Replays the current mission with the hearts the player had when it began.
function replay() {
    deathState.on = false;
    paused = false;
    musicDuck = 1;
    applyMusic(.5);
    combo = 0;
    comboTimer = 0;
    bestComboThisLife = 0;
    popups = [];
    particles = [];
    const S = stageSnapshot;
    score = S.score;
    scoreParts.kills = S.sck;
    scoreParts.bonus = S.scb;
    screenFlash = 0;
    screenShake = 0;
    narrationQueue = [];
    narration = {};
    fadeIn();
    if (S.kind == 'play') {
        startLevel(S.lvl, S.hp);
        player.fbar = S.fbar || 0;
        saveStageSnapshot();
        showBanner('LEVEL ' + S.lvl, 'Replay with ' + S.hp + ' hearts');
    }
    else if (S.kind == 'boss') {
        player.hp = S.hp;
        boss();
        showBanner('THE DRAGON', 'Replay with ' + S.hp + ' hearts');
    }
    else {
        act2(S.hp);
        showBanner('ACT II', 'Replay with ' + S.hp + ' hearts');
    }
    kills = S.kills;
}
// Starts over from the very beginning.
function restartGame() {
    creditsOn = false;
    deathState.on = false;
    paused = false;
    musicDuck = 1;
    applyMusic(.5);
    run();
    fadeIn();
}
// Back to the title screen.
function gotoMenu() {
    creditsOn = false;
    gameState = 'title';
    card = 0;
    narrationQueue = [];
    narration = {};
    deathState.on = false;
    paused = false;
    musicDuck = 1;
    palette = PALETTE_DUNGEON;
    background = BACKGROUNDS[0];
    banner = null;
    popups = [];
    particles = [];
    keysDown.M = 0;
    menuT = 0;
    menuSel = 0;
    splash = randomItem(SPL);
    setMusic(0);
    applyMusic(.5);
    fadeIn();
}
function beginAdventure() {
    startIntro('game');
}
