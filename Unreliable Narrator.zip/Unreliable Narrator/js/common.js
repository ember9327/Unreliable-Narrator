// Shared setup: canvases, colour palettes and sprite loading.

const byId = i => document.getElementById(i), gameCtx = byId('c').getContext('2d'), uiCtx = byId('u').getContext('2d');
const GAME_W = 320, GAME_H = 180, rand = Math.random, TAU = Math.PI * 2, PI = Math.PI;
const lightCanvas = document.createElement('canvas');
lightCanvas.width = GAME_W;
lightCanvas.height = GAME_H;
const lightCtx = lightCanvas.getContext('2d');
const PALETTE_DUNGEON = { wall: '#1c1838', brick: '#2c2657', f1: '#302a5c', f2: '#28234f', crack: '#1a1634', win: '#3b4a8f', moon: '#dfe8ff', dark: 'rgba(6,4,22,.68)', gl: '255,175,80', fl: '#ff8a3d', acc: '#f2c14e', fog: '190,200,255' };
const PALETTE_BLOOD = { wall: '#2a0f18', brick: '#4a1a26', f1: '#4a2230', f2: '#3d1a27', crack: '#240b12', win: '#7a1f2b', moon: '#ff7a45', dark: 'rgba(28,3,8,.7)', gl: '255,80,50', fl: '#ff3d5a', acc: '#ff5d73', fog: '255,120,90' };
let palette = PALETTE_DUNGEON, background;
// ---------- sprites (loaded from assets/) ----------
const whiteSilhouette = c => {
    const n = document.createElement('canvas');
    n.width = c.width;
    n.height = c.height;
    const x = n.getContext('2d');
    x.drawImage(c, 0, 0);
    x.globalCompositeOperation = 'source-in';
    x.fillStyle = '#fff';
    x.fillRect(0, 0, n.width, n.height);
    return n;
};
const loadImage = u => new Promise(r => {
    const i = new Image();
    i.onload = () => r(i);
    i.src = u;
});
const SPRITES = {}, WHITE_SPRITES = {};
const SPRITE_FILES = { k: 'knight', gh: 'ghost', imp: 'imp', b1: 'bat1', b2: 'bat2', crawl: 'crawler', float: 'floater', dr: 'dragon', pr: 'princess', door: 'door' };
async function loadSprites() {
    await Promise.all(Object.entries(SPRITE_FILES).map(async ([key, file]) => {
        const img = await loadImage(`assets/sprites/${file}.png`);
        SPRITES[key] = img;
        WHITE_SPRITES[key] = whiteSilhouette(img);
    }));
}
// ---------- background (loaded from assets/) ----------
const BACKGROUNDS = [];
async function loadBG() {
    BACKGROUNDS[0] = await loadImage('assets/bg/dungeon_blue.png');
    BACKGROUNDS[1] = await loadImage('assets/bg/dungeon_red.png');
}
