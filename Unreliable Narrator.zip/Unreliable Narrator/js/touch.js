// On-screen touch controls for phones and tablets.

// ================= TOUCH CONTROLS (floating stick + buttons for phones and tablets) =================
const touchRoot = document.createElement('div');
touchRoot.id = 'touch';
byId('w').appendChild(touchRoot);
let touchMode = false; // true once we know the player is on a touch screen
let stickId = null; // pointer that currently owns the stick
const stick = { ox: 0, oy: 0, maxR: 1, fx: 0, fy: 0 };
const isJoystickMode = () => settings.pad === 'joystick';
// keeps receiving move/up events even when the finger slides off the element
function capturePointer(el, id) {
    try {
        el.setPointerCapture(id);
    }
    catch (err) {
    }
}
function setTouchMode(on) {
    touchMode = on;
    if (on) {
        touchRoot.classList.add('active');
    }
}
if (window.matchMedia && matchMedia('(pointer: coarse)').matches) {
    setTouchMode(true);
}
addEventListener('pointerdown', e => {
    if (e.pointerType === 'touch') {
        setTouchMode(true);
    }
}, true);
// ---- sizing: everything is measured in "u" = 1% of the game width ----
function sizeTouchUi() {
    byId('w').style.setProperty('--u', (byId('w').clientWidth / 100) + 'px');
    stick.maxR = byId('w').clientWidth * 0.07;
    // resting spot of the stick when the "joystick" style is chosen (relative to the game area)
    stick.fx = byId('w').clientWidth * 0.15;
    stick.fy = byId('w').clientHeight - byId('w').clientWidth * 0.14;
    placeStick(stick.fx, stick.fy);
}
addEventListener('resize', sizeTouchUi);
addEventListener('orientationchange', () => setTimeout(sizeTouchUi, 150));
// ---- floating stick ----
const stickZone = document.createElement('div');
stickZone.className = 'tc zone';
const stickBase = document.createElement('div');
stickBase.className = 'stickbase';
const stickKnob = document.createElement('div');
stickKnob.className = 'stickknob';
stickBase.appendChild(stickKnob);
touchRoot.appendChild(stickZone);
touchRoot.appendChild(stickBase);
sizeTouchUi();
function placeStick(x, y) {
    stickBase.style.left = x + 'px';
    stickBase.style.top = y + 'px';
}
function moveStick(clientX, clientY) {
    const dx = clientX - stick.ox, dy = clientY - stick.oy;
    const dist = Math.hypot(dx, dy) || 1;
    const k = Math.min(1, stick.maxR / dist);
    stickKnob.style.transform = 'translate(' + (dx * k) + 'px,' + (dy * k) + 'px)';
    const dead = stick.maxR * 0.3;
    TOUCH.left = dx < -dead;
    TOUCH.right = dx > dead;
    TOUCH.up = dy < -dead;
    TOUCH.down = dy > dead;
}
function releaseStick() {
    stickId = null;
    if (!isJoystickMode()) {
        stickBase.style.display = 'none';
    }
    stickKnob.style.transform = '';
    TOUCH.left = TOUCH.right = TOUCH.up = TOUCH.down = false;
}
stickZone.addEventListener('pointerdown', e => {
    e.preventDefault();
    e.stopPropagation();
    startAudio();
    if (stickId !== null) {
        return;
    }
    stickId = e.pointerId;
    capturePointer(stickZone, e.pointerId);
    const rect = byId('w').getBoundingClientRect();
    if (isJoystickMode()) {
        // fixed stick: always measured from its resting spot
        stick.ox = rect.left + stick.fx;
        stick.oy = rect.top + stick.fy;
        placeStick(stick.fx, stick.fy);
    }
    else {
        // touch style: the stick appears wherever the finger lands
        stick.ox = e.clientX;
        stick.oy = e.clientY;
        placeStick(e.clientX - rect.left, e.clientY - rect.top);
    }
    stickBase.style.display = 'block';
    moveStick(e.clientX, e.clientY);
});
stickZone.addEventListener('pointermove', e => {
    if (e.pointerId === stickId) {
        moveStick(e.clientX, e.clientY);
    }
});
['pointerup', 'pointercancel', 'lostpointercapture'].forEach(type => stickZone.addEventListener(type, e => {
    if (e.pointerId === stickId) {
        releaseStick();
    }
}));
// ---- round buttons ----
// A "hold" button keeps TOUCH[name] true while it is pressed. A "tap" button just runs a function.
/** Creates one round on-screen button. */
function makeButton(name, label, className, hold, action) {
    const b = document.createElement('div');
    b.className = 'tc tbtn ' + className;
    b.style.backgroundImage = 'url(' + textImage(label, 4, '#ffffff', null, '#000').toDataURL() + ')';
    b.addEventListener('pointerdown', e => {
        e.preventDefault();
        e.stopPropagation();
        startAudio();
        capturePointer(b, e.pointerId);
        b.classList.add('on');
        if (hold) {
            TOUCH[name] = true;
        }
        else {
            action();
        }
    });
    const release = () => {
        b.classList.remove('on');
        if (hold) {
            TOUCH[name] = false;
        }
    };
    ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(type => b.addEventListener(type, release));
    b.addEventListener('contextmenu', e => e.preventDefault());
    touchRoot.appendChild(b);
    return b;
}
const btnAttack = makeButton('attack', 'ATK', 'b-attack', true);
const btnJump = makeButton('jump', 'JMP', 'b-jump', true);
const btnSprint = makeButton('sprint', 'RUN', 'b-sprint', true);
const btnFinish = makeButton('finish', 'FIN', 'b-finish', false, () => finisher());
const btnUlt = makeButton('ultimate', 'ULT', 'b-ult', false, () => ultimate());
const btnPause = makeButton('pause', 'II', 'b-small b-pause', false, () => {
    if (inGame() && !deathState.on && card === 0) {
        paused = true;
        playUiSound('back');
    }
});
const btnFull = makeButton('full', '[]', 'b-small b-full', false, toggleFullscreen);
/** Enters or leaves fullscreen (and tries to lock landscape on phones). */
function toggleFullscreen() {
    const el = document.documentElement;
    if (document.fullscreenElement || document.webkitFullscreenElement) {
        (document.exitFullscreen || document.webkitExitFullscreen).call(document);
        return;
    }
    const req = el.requestFullscreen || el.webkitRequestFullscreen;
    if (!req) {
        return;
    }
    const p = req.call(el);
    const lock = () => {
        if (screen.orientation && screen.orientation.lock) {
            screen.orientation.lock('landscape').catch(() => {
            });
        }
    };
    if (p && p.then) {
        p.then(lock).catch(() => {
        });
    }
    else {
        lock();
    }
}
// ---- show / hide the right controls for the current screen (called every frame) ----
const show = (el, on) => {
    el.style.display = on ? 'block' : 'none';
};
/** Shows only the touch controls that make sense right now. */
function syncTouchUi() {
    const playing = touchMode && inGame() && !deathState.on && !paused && gameState !== 'end' && gameState !== 'twist';
    show(stickZone, playing);
    // joystick style keeps the stick on screen all the time; touch style only shows it while pressed
    if (playing && isJoystickMode()) {
        stickBase.style.display = 'block';
    }
    else if (stickId === null) {
        stickBase.style.display = 'none';
    }
    show(btnAttack, playing);
    show(btnJump, playing && gameState === 'play');
    show(btnSprint, playing);
    show(btnFinish, playing);
    show(btnUlt, playing && gameState === 'act2');
    show(btnPause, playing);
    show(btnFull, touchMode && gameState !== 'intro' && fullscreenSupported);
    if (!playing && stickId !== null) {
        releaseStick();
    }
    if (!playing) {
        TOUCH.attack = TOUCH.jump = TOUCH.sprint = false;
    }
    // keep the game from running while a phone is held upright
    if (touchMode && window.innerHeight > window.innerWidth && inGame() && !deathState.on && gameState !== 'twist') {
        paused = true;
    }
}
const fullscreenSupported = !!(document.documentElement.requestFullscreen || document.documentElement.webkitRequestFullscreen);
