// Sound: music tracks, sound effects, volume and menu beeps.

// ---------- audio (WebAudio; sounds are decoded from audio-data.js so it also works when index.html is opened straight from disk) ----------
let currentTrack = -1, audioStarted = false;
const settings = { music: .8, sfx: .9, shake: 1, pad: 'touch' };
let audioCtx = null, musicGain = null, sfxGain = null, musicDuck = 1;
const SOUND_BUFFERS = {}, MUSIC_GAINS = {};
const SFX_FILES = ['swing', 'hit', 'kill', 'hurt', 'blip', 'step', 'clear', 'boom', 'fire', 'roar', 'glitch', 'screech', 'drip', 'growl', 'thump', 'whisper', 'chain_rattle', 'stinger', 'sprint', 'finisher', 'telegraph'];
const MUS_FILES = { act1: 'assets/music/act1_theme.wav', act2: 'assets/music/act2_theme.wav', amb: 'assets/music/ambience.wav' };
const musTarget = { act1: 0, act2: 0, amb: .5 };
function base64ToBuffer(s) {
    const bin = atob(s), u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) {
        u[i] = bin.charCodeAt(i);
    }
    return u.buffer;
}
async function audioBytes(url) {
    const e = window.AUDIO_DATA && window.AUDIO_DATA[url];
    if (e) {
        return base64ToBuffer(e);
    }
    const r = await fetch(url);
    return await r.arrayBuffer();
}
const decodeBuf = (ctx, ab) => new Promise((res, rej) => {
    const pr = ctx.decodeAudioData(ab, res, rej);
    if (pr && pr.catch) {
        pr.catch(rej);
    }
});
/** Creates the audio context and decodes every sound file. */
async function loadAudio() {
    const AC0 = window.AudioContext || window.webkitAudioContext;
    if (!AC0) {
        throw new Error('WebAudio not supported');
    }
    audioCtx = new AC0();
    musicGain = audioCtx.createGain();
    sfxGain = audioCtx.createGain();
    musicGain.connect(audioCtx.destination);
    sfxGain.connect(audioCtx.destination);
    applyVol();
    const jobs = [...SFX_FILES.map(n => [n, `assets/sfx/${n}.wav`]), ...Object.entries(MUS_FILES)];
    await Promise.all(jobs.map(async ([n, u]) => {
        try {
            SOUND_BUFFERS[n] = await decodeBuf(audioCtx, await audioBytes(u));
        }
        catch (e) {
            console.warn('audio skipped:', n, e);
        }
    }));
}
function applyVol() {
    if (!audioCtx) {
        return;
    }
    musicGain.gain.value = settings.music;
    sfxGain.gain.value = settings.sfx;
}
function applyMusic(dur) {
    if (!audioCtx) {
        return;
    }
    dur = dur || .8;
    for (const n in MUSIC_GAINS) {
        const v = (musTarget[n] || 0) * musicDuck;
        MUSIC_GAINS[n].gain.cancelScheduledValues(audioCtx.currentTime);
        MUSIC_GAINS[n].gain.setTargetAtTime(v, audioCtx.currentTime, dur / 3);
    }
}
/** Starts the looping music. Must be called from a click or key press. */
function startAudio() {
    if (!audioCtx) {
        return;
    }
    if (audioCtx.state !== 'running' && audioCtx.resume) {
        audioCtx.resume();
    }
    if (audioStarted) {
        return;
    }
    audioStarted = true;
    for (const n in MUS_FILES) {
        if (!SOUND_BUFFERS[n]) {
            continue;
        }
        const s = audioCtx.createBufferSource();
        s.buffer = SOUND_BUFFERS[n];
        s.loop = true;
        const gn = audioCtx.createGain();
        gn.gain.value = 0;
        s.connect(gn);
        gn.connect(musicGain);
        s.start(0);
        MUSIC_GAINS[n] = gn;
    }
    applyMusic(.3);
}
function setMusic(idx) {
    currentTrack = idx;
    musTarget.act1 = idx == 0 ? .5 : 0;
    musTarget.act2 = idx == 1 ? .45 : 0;
    applyMusic(.8);
}
/** Plays one sound effect from the loaded buffers. */
function playSound(n, vol, rate) {
    if (!audioCtx || audioCtx.state !== 'running' || !SOUND_BUFFERS[n]) {
        return;
    }
    const s = audioCtx.createBufferSource();
    s.buffer = SOUND_BUFFERS[n];
    if (rate) {
        s.playbackRate.value = rate;
    }
    const gn = audioCtx.createGain();
    gn.gain.value = vol == null ? 1 : vol;
    s.connect(gn);
    gn.connect(sfxGain);
    s.start(0);
}
/** Plays a short synthesized beep (used for menu sounds). */
function playTone(f0, f1, dur, type, vol) {
    if (!audioCtx || audioCtx.state !== 'running') {
        return;
    }
    const o = audioCtx.createOscillator(), gn = audioCtx.createGain(), t = audioCtx.currentTime;
    o.type = type || 'square';
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    gn.gain.setValueAtTime(vol == null ? .12 : vol, t);
    gn.gain.exponentialRampToValueAtTime(.001, t + dur);
    o.connect(gn);
    gn.connect(sfxGain);
    o.start(t);
    o.stop(t + dur + .02);
}
function playUiSound(k) {
    if (k == 'hover') {
        playTone(660, 880, .05, 'square', .05);
    }
    else if (k == 'click') {
        playTone(300, 560, .09, 'square', .12);
    }
    else if (k == 'back') {
        playTone(520, 240, .1, 'square', .1);
    }
    else if (k == 'bad') {
        playTone(200, 90, .25, 'sawtooth', .12);
    }
    else if (k == 'coin') {
        playTone(880, 1320, .09, 'square', .07);
    }
}
