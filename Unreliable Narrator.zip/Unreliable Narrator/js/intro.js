// Intro video playback.

// ================= INTRO CUTSCENE (plays the video in assets/video/) =================
const introVideo = byId('introVideo');
const skipHint = byId('skipHint');
let introThen = 'game'; // what to do afterwards: 'game' starts the adventure, 'menu' goes back to the title
let introDone = true;
/** Plays the intro video, then continues to the game or back to the menu. */
function startIntro(then) {
    introThen = then;
    introDone = false;
    gameState = 'intro';
    card = 0;
    narrationQueue = [];
    narration = {};
    deathState.on = false;
    paused = false;
    banner = null;
    popups = [];
    particles = [];
    // the video has its own music, so the game music stays quiet while it plays
    musicDuck = 0;
    applyMusic(0.2);
    skipHint.textContent = touchMode ? 'TAP TO SKIP' : 'ENTER OR CLICK TO SKIP';
    skipHint.style.display = 'block';
    introVideo.style.display = 'block';
    introVideo.volume = Math.max(0.15, Math.max(settings.music, settings.sfx));
    introVideo.muted = false;
    introVideo.currentTime = 0;
    const started = introVideo.play();
    if (started && started.catch) {
        // some browsers refuse to start a video with sound, so try again silently before giving up
        started.catch(() => {
            introVideo.muted = true;
            const retry = introVideo.play();
            if (retry && retry.catch) {
                retry.catch(endIntro);
            }
        });
    }
}
/** Lets the player skip the intro video. */
function skipIntro() {
    if (!introDone) {
        playUiSound('back');
        endIntro();
    }
}
function endIntro() {
    if (introDone) {
        return;
    }
    introDone = true;
    introVideo.pause();
    introVideo.style.display = 'none';
    skipHint.style.display = 'none';
    musicDuck = 1;
    applyMusic(0.6);
    if (introThen === 'game') {
        run();
        fadeIn();
    }
    else {
        gotoMenu();
    }
}
introVideo.addEventListener('ended', endIntro);
// if neither video file can be played the game just carries on without the intro
const videoSources = introVideo.querySelectorAll('source');
videoSources[videoSources.length - 1].addEventListener('error', endIntro);
