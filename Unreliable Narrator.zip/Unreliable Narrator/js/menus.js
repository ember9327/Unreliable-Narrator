// Menus and overlays: title, settings, pause, death, final score and the HUD.

// ================= UI PLUMBING (buttons, pointer, stone textures) =================
const buttons = [];
let hoveredId = null, pressId = null, drag = null, rebind = null, menuT = 0, menuSel = 0, setBack = 'title', splash = '', endShown = 0, creditsOn = false, creditsFrom = 'title', creditsT = 0;
const SPL = ['He is lying!', 'Trust me!', '100% reliable!', 'Dragons have feelings!', 'Now with hearts!', 'Mind the pit!', 'Press J to stab!', 'Totally true!', 'Ask no questions!', 'Not a bat!', 'Narrator approved!', 'Mostly honest!'];
const embers = Array.from({ length: 46 }, () => ({ x: rand() * 960, y: rand() * 540, s: 2 + (rand() * 3 | 0), v: 12 + rand() * 34, ph: rand() * 6, h: rand(), a: .25 + rand() * .55 }));
const sbC = new Map();
function stoneImg(w, h, mode) {
    const key = w + 'x' + h + '/' + mode;
    let c = sbC.get(key);
    if (c) {
        return c;
    }
    c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    const x = c.getContext('2d');
    let seed = w * 131 + h * 17 + mode * 7;
    const rnd = () => {
        seed = (seed * 16807) % 2147483647;
        return seed / 2147483647;
    };
    const base = mode == 2 ? [132, 136, 164] : mode == 0 ? [62, 62, 76] : [100, 103, 128];
    x.fillStyle = `rgb(${base})`;
    x.fillRect(0, 0, w, h);
    for (let i = 0; i < w * h / 22; i++) {
        const sx = rnd() * w | 0, sy = rnd() * h | 0;
        x.fillStyle = rnd() < .5 ? 'rgba(255,255,255,.1)' : 'rgba(0,0,0,.16)';
        x.fillRect(sx, sy, 2 + (rnd() * 3 | 0), 2);
    }
    x.fillStyle = 'rgba(255,255,255,.4)';
    x.fillRect(0, 0, w, 3);
    x.fillRect(0, 0, 3, h);
    x.fillStyle = 'rgba(0,0,0,.45)';
    x.fillRect(0, h - 3, w, 3);
    x.fillRect(w - 3, 0, 3, h);
    x.fillStyle = '#07040f';
    x.fillRect(0, 0, w, 2);
    x.fillRect(0, h - 2, w, 2);
    x.fillRect(0, 0, 2, h);
    x.fillRect(w - 2, 0, 2, h);
    if (mode == 2) {
        x.fillStyle = 'rgba(242,193,78,.55)';
        x.fillRect(2, 2, w - 4, 2);
        x.fillRect(2, h - 4, w - 4, 2);
    }
    sbC.set(key, c);
    return c;
}
function addBtn(id, x, y, w, h, label, o) {
    o = o || {};
    const b = { id, x, y, w, h, dis: !!o.dis, slider: o.slider };
    buttons.push(b);
    if (o.draw === false) {
        return b;
    }
    const hv = !b.dis && (hoveredId === id || (o.sel && hoveredId == null)), pr = pressId === id;
    uiCtx.drawImage(stoneImg(w, h, b.dis ? 0 : hv ? 2 : 1), x, y + (pr ? 2 : 0));
    if (label != null) {
        const s = o.s || 3;
        drawText(label, x + w / 2, y + (h - 7 * s) / 2 + (pr ? 2 : 0), s, b.dis ? '#8a8a98' : hv ? '#ffffa0' : '#ffffff', { al: 'c', sh: '#2a2a38' });
    }
    return b;
}
function panel(x, y, w, h, a) {
    uiCtx.fillStyle = `rgba(10,7,22,${a == null ? .88 : a})`;
    uiCtx.fillRect(x, y, w, h);
    uiCtx.fillStyle = '#07040f';
    uiCtx.fillRect(x - 4, y - 4, w + 8, 4);
    uiCtx.fillRect(x - 4, y + h, w + 8, 4);
    uiCtx.fillRect(x - 4, y, 4, h);
    uiCtx.fillRect(x + w, y, 4, h);
    uiCtx.fillStyle = 'rgba(242,193,78,.55)';
    uiCtx.fillRect(x, y, w, 2);
    uiCtx.fillRect(x, y + h - 2, w, 2);
    uiCtx.fillRect(x, y, 2, h);
    uiCtx.fillRect(x + w - 2, y, 2, h);
}
function uiPos(e) {
    const r = byId('w').getBoundingClientRect();
    return [(e.clientX - r.left) / r.width * 960, (e.clientY - r.top) / r.height * 540];
}
function buttonAt(x, y) {
    for (let i = buttons.length - 1; i >= 0; i--) {
        const b = buttons[i];
        if (!b.dis && x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h) {
            return b;
        }
    }
    return null;
}
function sliderSet(b, x) {
    const v = Math.max(0, Math.min(1, (x - b.x) / b.w));
    if (b.id == 'vol:music') {
        settings.music = v;
        applyVol();
    }
    else {
        settings.sfx = v;
        applyVol();
    }
}
const inGame = () => ['play', 'boss', 'act2', 'twist', 'end'].includes(gameState);
function onBtn(b) {
    const id = b.id;
    playUiSound('click');
    if (id == 'play') {
        beginAdventure();
    }
    else if (id == 'intro') {
        startIntro('menu');
    }
    else if (id == 'set') {
        setBack = 'title';
        gameState = 'settings';
        rebind = null;
    }
    else if (id == 'credits' || id == 'credits_end') {
        creditsFrom = id == 'credits' ? 'title' : 'end';
        creditsOn = true;
        creditsT = 0;
    }
    else if (id == 'cback') {
        creditsOn = false;
    }
    else if (id == 'back') {
        gameState = setBack == 'pause' ? (prevSt || 'play') : 'title';
        rebind = null;
        saveSettings();
    }
    else if (id == 'reset') {
        keyBindings = JSON.parse(JSON.stringify(DEFAULT_KEYS));
        saveSettings();
    }
    else if (id == 'pad:touch' || id == 'pad:joystick') {
        settings.pad = id.slice(4);
        saveSettings();
    }
    else if (id == 'shake') {
        settings.shake = settings.shake ? 0 : 1;
        saveSettings();
    }
    else if (id.startsWith('k:')) {
        const [, a, s] = id.split(':');
        rebind = { a, s: +s };
    }
    else if (id == 'replay') {
        replay();
    }
    else if (id == 'restart') {
        restartGame();
    }
    else if (id == 'menu') {
        gotoMenu();
    }
    else if (id == 'resume') {
        paused = false;
    }
    else if (id == 'pset') {
        setBack = 'pause';
        prevSt = gameState;
        gameState = 'settings';
        rebind = null;
    }
    else if (id == 'again') {
        restartGame();
    }
}
let prevSt = null;
onpointermove = e => {
    const [x, y] = uiPos(e);
    const b = buttonAt(x, y), nid = b ? b.id : null;
    if (nid !== hoveredId) {
        hoveredId = nid;
        if (nid && !b.slider) {
            playUiSound('hover');
        }
        if (nid && gameState == 'title') {
            const i = ['play', 'set', 'intro', 'credits'].indexOf(nid);
            if (i >= 0) {
                menuSel = i;
            }
        }
    }
    if (drag) {
        sliderSet(drag, x);
    }
};
onpointerdown = e => {
    startAudio();
    const [x, y] = uiPos(e), b = buttonAt(x, y);
    if (b) {
        pressId = b.id;
        hoveredId = b.id;
        if (b.slider) {
            drag = b;
            sliderSet(b, x);
        }
        return;
    }
    if (gameState == 'intro') {
        skipIntro();
        return;
    }
    if (card == 1 && gameState == 'twist') {
        act2();
        return;
    }
    if (inGame() && !deathState.on && !paused && gameState != 'end' && e.pointerType !== 'touch') {
        keysDown.M = 1;
    }
};
onpointerup = e => {
    keysDown.M = 0;
    if (drag) {
        drag = null;
        saveSettings();
        playUiSound('click');
        pressId = null;
        return;
    }
    if (pressId) {
        const [x, y] = uiPos(e), b = buttonAt(x, y);
        const id = pressId;
        pressId = null;
        if (b && b.id === id) {
            onBtn(b);
        }
    }
};
// ================= KEYBOARD =================
onkeydown = e => {
    if (rebind) {
        e.preventDefault();
        if (e.code == 'Escape') {
            rebind = null;
            return;
        }
        const v = (e.code == 'Backspace' || e.code == 'Delete') ? '' : e.code;
        keyBindings[rebind.a][rebind.s] = v;
        rebind = null;
        saveSettings();
        playUiSound('click');
        return;
    }
    keysDown[e.code] = 1;
    startAudio();
    if (e.code.startsWith('Arrow') || e.code == 'Space' || e.code == 'Tab') {
        e.preventDefault();
    }
    if (gameState == 'intro') {
        if (e.code == 'Enter' || e.code == 'Space' || e.code == 'Escape') {
            skipIntro();
        }
        return;
    }
    if (creditsOn && creditsFrom == 'title') {
        if (e.code == 'Escape' || e.code == 'Enter' || e.code == 'Space') {
            creditsOn = false;
            playUiSound('back');
        }
        return;
    }
    if (card == 2 && !creditsOn && endT > 3.5 && (e.code == 'Enter' || e.code == 'Space')) {
        onBtn({ id: 'credits_end' });
        return;
    }
    if (gameState == 'title') {
        const n = 4, go = ['play', 'set', 'intro', 'credits'];
        if (e.code == 'ArrowDown' || e.code == 'KeyS') {
            menuSel = (menuSel + 1) % n;
            hoveredId = null;
            playUiSound('hover');
        }
        else if (e.code == 'ArrowUp' || e.code == 'KeyW') {
            menuSel = (menuSel + n - 1) % n;
            hoveredId = null;
            playUiSound('hover');
        }
        else if (e.code == 'Enter' || e.code == 'Space') {
            onBtn({ id: go[menuSel] });
        }
        return;
    }
    if (gameState == 'settings') {
        if (e.code == 'Escape') {
            onBtn({ id: 'back' });
        }
        return;
    }
    if (deathState.on) {
        if (deathState.t < .9) {
            return;
        }
        if (e.code == 'KeyR') {
            replay();
        }
        else if (e.code == 'KeyX') {
            restartGame();
        }
        else if (e.code == 'Escape') {
            gotoMenu();
        }
        else if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'KeyA', 'KeyD', 'KeyW', 'KeyS'].includes(e.code)) {
            deathState.sel ^= 1;
            playUiSound('hover');
        }
        else if (e.code == 'Enter' || e.code == 'Space') {
            deathState.sel ? restartGame() : replay();
        }
        return;
    }
    if (paused) {
        if (e.code == 'Escape' || e.code == 'KeyP') {
            paused = false;
        }
        return;
    }
    if (inGame() && (e.code == 'Escape' || e.code == 'KeyP') && card == 0) {
        paused = true;
        playUiSound('back');
        return;
    }
    if (card == 1 && gameState == 'twist' && (e.code == 'Space' || e.code == 'Enter')) {
        act2();
    }
    else if (card == 2 && e.code == 'KeyR') {
        restartGame();
    }
    else if (card == 2 && e.code == 'Escape') {
        gotoMenu();
    }
    if (keyBindings.finish.includes(e.code)) {
        finisher();
    }
    if (keyBindings.ultimate.includes(e.code)) {
        ultimate();
    }
};
onkeyup = e => keysDown[e.code] = 0;
onblur = () => {
    for (const k in keysDown) {
        keysDown[k] = 0;
    }
};
// ================= PER-FRAME UI UPDATE =================
function uiUpd(d) {
    fadeA = Math.max(0, fadeA - d * 1.6);
    if (gameState == 'title' || gameState == 'settings') {
        menuT += d;
        embers.forEach(m => {
            m.y -= m.v * d;
            m.x += Math.sin(time * .8 + m.ph) * 10 * d;
            if (m.y < -4) {
                m.y = 544;
                m.x = rand() * 960;
            }
        });
    }
    if (creditsOn) {
        creditsT += d;
    }
    syncTouchUi();
    if (paused || gameState == 'title' || gameState == 'settings' || gameState == 'intro') {
        return;
    }
    if (comboTimer > 0) {
        comboTimer -= d;
        if (comboTimer <= 0) {
            combo = 0;
        }
    }
    shownScore += ((score + comboBank) - shownScore) * Math.min(1, d * 9);
    if (Math.abs(score + comboBank - shownScore) < .6) {
        shownScore = score + comboBank;
    }
    scoreBump = Math.max(0, scoreBump - d * 4);
    popups.forEach(f => {
        f.t += d;
    });
    popups = popups.filter(f => f.t < f.l);
    if (banner) {
        banner.t += d;
        if (banner.t > 2.7) {
            banner = null;
        }
    }
    if (card == 2) {
        endT += d;
    }
    else {
        endT = 0;
    }
}
// ================= MENU BACKGROUND (low-res layer) =================
function menuLights(lts) {
    lightCtx.globalCompositeOperation = 'source-over';
    lightCtx.fillStyle = palette.dark;
    lightCtx.fillRect(0, 0, GAME_W, GAME_H);
    lightCtx.globalCompositeOperation = 'destination-out';
    lts.forEach(([x, y, r, a]) => {
        const gr = lightCtx.createRadialGradient(x, y, 0, x, y, r);
        gr.addColorStop(0, `rgba(0,0,0,${a})`);
        gr.addColorStop(1, 'rgba(0,0,0,0)');
        lightCtx.fillStyle = gr;
        lightCtx.fillRect(x - r, y - r, r * 2, r * 2);
    });
    gameCtx.drawImage(lightCanvas, 0, 0);
    gameCtx.globalCompositeOperation = 'lighter';
    glowAt(lts);
    gameCtx.globalCompositeOperation = 'source-over';
}
/** Animated dungeon background behind the menus. */
function drawMenuBg() {
    const dx = Math.sin(time * .12) * 5, dy = Math.cos(time * .09) * 2;
    gameCtx.fillStyle = '#07050f';
    gameCtx.fillRect(0, 0, GAME_W, GAME_H);
    gameCtx.drawImage(BACKGROUNDS[gameState == 'settings' ? 1 : 0], -10 + dx, -5 + dy, GAME_W + 20, GAME_H + 10);
    const sI = gameState == 'settings' ? 0 : 1;
    torch(22, 72);
    torch(298, 72);
    const br = 1 + Math.sin(time * 1.3) * .015, ds0 = 3.9 * br;
    if (sI) {
        drawSprite(SPRITES.dr, 64, 170, 1, null, ds0);
        drawSprite(SPRITES.k, 262, 162, -1, null, 1.5);
    }
    const fl = 1 + Math.sin(time * 13) * .05 + Math.sin(time * 7.3) * .05;
    menuLights([[22, 74, 95 * fl, .85, palette.gl], [298, 74, 95 * fl, .85, palette.gl], [160, 50, 150, .3, '150,170,255'], [64, 110, 60, .35, '255,70,50']]);
    if (sI) {
        gameCtx.globalCompositeOperation = 'lighter';
        const pul = .55 + Math.sin(time * 2.4) * .25;
        for (const ex of [7, 25]) {
            const X = 64 + (ex - 16) * ds0, Y = 170 - (30 - 12) * ds0;
            const gr = gameCtx.createRadialGradient(X, Y, 0, X, Y, 14);
            gr.addColorStop(0, `rgba(255,70,70,${pul})`);
            gr.addColorStop(1, 'rgba(255,70,70,0)');
            gameCtx.fillStyle = gr;
            gameCtx.fillRect(X - 14, Y - 14, 28, 28);
        }
        gameCtx.globalCompositeOperation = 'source-over';
    }
}
// ================= SCREENS =================
/** Title menu. */
function drawTitle() {
    uiCtx.fillStyle = 'rgba(4,2,12,.3)';
    uiCtx.fillRect(0, 0, 960, 540);
    const gl = uiCtx.createRadialGradient(480, 150, 10, 480, 150, 380);
    gl.addColorStop(0, `rgba(242,193,78,${.16 + Math.sin(time * 2) * .04})`);
    gl.addColorStop(1, 'rgba(242,193,78,0)');
    uiCtx.fillStyle = gl;
    uiCtx.fillRect(0, 0, 960, 360);
    embers.forEach(m => {
        uiCtx.fillStyle = `rgba(255,${130 + m.h * 90 | 0},60,${m.a * (.6 + Math.sin(time * 3 + m.ph) * .4)})`;
        uiCtx.fillRect(m.x | 0, m.y | 0, m.s, m.s);
    });
    logoOn(uiCtx, 480, 30, 12, menuT, true);
    const sk = clamp((menuT - 1.2) / .4, 0, 1);
    if (sk > 0) {
        uiCtx.save();
        uiCtx.translate(770, 230);
        uiCtx.rotate(-.3);
        const sp = (1 + Math.sin(time * 6) * .07) * easeBounce(sk);
        uiCtx.scale(sp, sp);
        drawText(splash, 0, -10, 3, '#ffff55', { al: 'c', sh: '#3f3f15' });
        uiCtx.restore();
    }
    const items = [['play', 'START ADVENTURE'], ['set', 'SETTINGS'], ['intro', 'WATCH INTRO'], ['credits', 'CREDITS']];
    items.forEach(([id, label], i) => {
        const k = clamp((menuT - 1 - i * .14) / .35, 0, 1), off = (1 - k) * (i % 2 ? 1 : -1) * 700;
        const bx = 290 + off;
        addBtn(id, bx, 274 + i * 48, 380, 40, label, { s: 3, sel: menuSel == i, dis: k < 1 });
    });
    drawText('BEST ' + String(bestScore).padStart(6, '0'), 22, 514, 2, '#bfb8a0', { sh: '#000' });
    drawText('TANTRAFIESTA 2026', 938, 514, 2, '#bfb8a0', { al: 'r', sh: '#000' });
    if (audioCtx && audioCtx.state !== 'running') {
        drawText('CLICK OR PRESS A KEY FOR SOUND', 480, 462, 2, '#f2c14e', { al: 'c', sh: '#000', a: .5 + Math.sin(time * 4) * .4 });
    }
    else {
        drawText(touchMode ? 'TAP A BUTTON' : 'W S OR ARROWS + ENTER  -  OR USE THE MOUSE', 480, 484, 2, '#7d7890', { al: 'c', sh: '#000' });
    }
}
function slider(id, x, y, w, label, val) {
    drawText(label, 120, y + 2, 3, '#f4ead2', { sh: '#000' });
    uiCtx.fillStyle = '#07040f';
    uiCtx.fillRect(x - 3, y - 3, w + 6, 22);
    uiCtx.fillStyle = '#2a2540';
    uiCtx.fillRect(x, y, w, 16);
    uiCtx.fillStyle = '#f2c14e';
    uiCtx.fillRect(x, y, w * val, 16);
    uiCtx.fillStyle = 'rgba(255,255,255,.25)';
    uiCtx.fillRect(x, y, w * val, 4);
    const hx = x + w * val, hv = hoveredId === id || drag && drag.id === id;
    uiCtx.drawImage(stoneImg(18, 30, hv ? 2 : 1), Math.round(hx - 9), y - 7);
    addBtn(id, x - 8, y - 8, w + 16, 32, null, { slider: true, draw: false });
    drawText(Math.round(val * 100) + '%', x + w + 30, y + 2, 3, '#ffffff', { sh: '#000' });
}
/** Settings screen: volumes and key rebinding. */
function drawSettings() {
    uiCtx.fillStyle = 'rgba(6,4,16,.8)';
    uiCtx.fillRect(0, 0, 960, 540);
    panel(50, 16, 860, 508, .55);
    embers.forEach(m => {
        uiCtx.fillStyle = `rgba(255,${130 + m.h * 90 | 0},60,${m.a * .5})`;
        uiCtx.fillRect(m.x | 0, m.y | 0, m.s, m.s);
    });
    drawText('SETTINGS', 480, 32, 6, '#f2c14e', { al: 'c', sh: '#3a2a08' });
    slider('vol:music', 420, 92, 340, 'MUSIC VOLUME', settings.music);
    slider('vol:sfx', 420, 132, 340, 'SOUND EFFECTS', settings.sfx);
    drawText('SCREEN SHAKE', 120, 176, 3, '#f4ead2', { sh: '#000' });
    addBtn('shake', 420, 168, 150, 34, settings.shake ? 'ON' : 'OFF', { s: 3 });
    drawText('CONTROLS', 480, 218, 4, '#f2c14e', { al: 'c', sh: '#3a2a08' });
    if (touchMode) {
        // phones and tablets have no keyboard, so they pick a control style instead
        const styles = [['pad:touch', 'TOUCH', 'touch', 170], ['pad:joystick', 'JOYSTICK', 'joystick', 490]];
        styles.forEach(([id, label, value, bx]) => {
            addBtn(id, bx, 262, 300, 64, label, { s: 4 });
            if (settings.pad === value) {
                uiCtx.strokeStyle = '#f2c14e';
                uiCtx.lineWidth = 4;
                uiCtx.strokeRect(bx - 2, 260, 304, 68);
                drawText('SELECTED', bx + 150, 340, 2, '#f2c14e', { al: 'c', sh: '#000' });
            }
        });
        if (settings.pad === 'touch') {
            drawText('PRESS ANYWHERE ON THE LEFT SIDE', 480, 384, 2, '#bfb8a0', { al: 'c' });
            drawText('AND THE STICK APPEARS UNDER YOUR FINGER', 480, 410, 2, '#bfb8a0', { al: 'c' });
        }
        else {
            drawText('A FIXED STICK STAYS ON THE LEFT', 480, 384, 2, '#bfb8a0', { al: 'c' });
            drawText('DRAG IT TO MOVE', 480, 410, 2, '#bfb8a0', { al: 'c' });
        }
        addBtn('back', 365, 466, 230, 38, 'DONE', { s: 3 });
        return;
    }
    drawText(rebind ? 'PRESS A KEY...  ESC CANCELS' : 'CLICK A BOX, THEN PRESS A KEY.  BACKSPACE CLEARS.', 480, 252, 2, rebind ? '#ffff55' : '#9a94b0', { al: 'c', a: rebind ? .6 + Math.sin(time * 8) * .4 : 1 });
    ACTIONS.forEach(([a, label], i) => {
        const col = i < 5 ? 0 : 1, row = i < 5 ? i : i - 5, bx = col ? 500 : 80, by = 276 + row * 34;
        drawText(label, bx, by + 8, 2, '#f4ead2', { sh: '#000' });
        for (let s = 0; s < 2; s++) {
            const id = `k:${a}:${s}`, on = rebind && rebind.a == a && rebind.s == s, sx = bx + (col ? 170 : 170) + s * 112;
            const b = addBtn(id, sx, by, 104, 28, null, {});
            const bl = on ? '...' : keyName(keyBindings[a][s]);
            if (on) {
                uiCtx.strokeStyle = '#ffff55';
                uiCtx.lineWidth = 2;
                uiCtx.strokeRect(sx + 1, by + 1, 102, 26);
            }
            drawText(bl, sx + 52, by + 7, 2, on ? '#ffff55' : keyBindings[a][s] ? '#ffffff' : '#7d7890', { al: 'c', sh: '#2a2a38' });
        }
    });
    drawText('MOUSE CLICK ALSO ATTACKS', 500, 426, 2, '#7d7890', {});
    addBtn('reset', 80, 466, 230, 38, 'RESET KEYS', { s: 3 });
    addBtn('back', 650, 466, 230, 38, 'DONE', { s: 3 });
}
/** Credits screen, opened from the title screen and after the final score. */
function drawCredits() {
    uiCtx.fillStyle = creditsFrom == 'end' ? 'rgba(0,0,0,.92)' : 'rgba(6,4,16,.82)';
    uiCtx.fillRect(0, 0, 960, 540);
    panel(50, 16, 860, 508, .55);
    embers.forEach(m => {
        uiCtx.fillStyle = `rgba(255,${130 + m.h * 90 | 0},60,${m.a * .5})`;
        uiCtx.fillRect(m.x | 0, m.y | 0, m.s, m.s);
    });
    // each line fades in a little after the one above it
    const line = (i, txt, y, size, col) => {
        const k = clamp((creditsT - i * .22) / .5, 0, 1);
        drawText(txt, 480, y, size, col, { al: 'c', sh: '#000', a: k });
    };
    line(0, 'UNRELIABLE NARRATOR', 40, 6, '#f2c14e');
    line(1, 'A GAME BY SIDDHARTH JAIN', 100, 4, '#f4ead2');
    line(2, 'MADE FOR IIITN GAME JAM - TANTRAFIESTA 2026', 146, 2, '#bfb8a0');
    uiCtx.fillStyle = 'rgba(242,193,78,.5)';
    uiCtx.fillRect(230, 176, 500, 2);
    line(3, 'DESIGN, STORY, CODE, PIXEL ART, MUSIC AND SOUND', 200, 2, '#bfb8a0');
    line(4, 'SIDDHARTH JAIN', 224, 3, '#ffffff');
    line(5, 'BUILT WITH HTML5, CSS AND JAVASCRIPT', 268, 2, '#bfb8a0');
    line(6, 'FONTS: CUSTOM PIXEL FONT, GEORGIA AND TIMES NEW ROMAN', 298, 2, '#bfb8a0');
    line(7, 'SPECIAL THANKS', 346, 3, '#f2c14e');
    line(8, 'TANTRAFIESTA AND IIIT NAGPUR', 380, 2, '#f4ead2');
    line(9, 'THANK YOU FOR PLAYING', 420, 3, '#9fe8c8');
    if (creditsFrom == 'end') {
        addBtn('again', 250, 462, 210, 46, 'PLAY AGAIN', { s: 3 });
        addBtn('menu', 500, 462, 210, 46, 'MAIN MENU', { s: 3 });
    }
    else {
        addBtn('cback', 365, 462, 230, 46, 'BACK', { s: 3 });
    }
}
/** Pause menu. */
function drawPause() {
    uiCtx.fillStyle = 'rgba(4,2,12,.7)';
    uiCtx.fillRect(0, 0, 960, 540);
    drawText('PAUSED', 480, 130, 8, '#f2c14e', { al: 'c', sh: '#3a2a08', out: '#07040f' });
    addBtn('resume', 290, 250, 380, 46, 'RESUME', { s: 3 });
    addBtn('pset', 290, 308, 380, 46, 'SETTINGS', { s: 3 });
    addBtn('menu', 290, 366, 380, 46, 'MAIN MENU', { s: 3 });
    if (!touchMode) {
        drawText(firstKeyName('attack') + ' ATTACK   ' + firstKeyName('finish') + ' FINISH   ESC RESUME', 480, 440, 2, '#7d7890', { al: 'c' });
    }
}
/** The YOU DIED screen with the replay and restart buttons. */
function drawDead() {
    const t = deathState.t, a = clamp(t / 1.2, 0, 1);
    uiCtx.fillStyle = `rgba(12,0,6,${.62 * a})`;
    uiCtx.fillRect(0, 0, 960, 540);
    const vg = uiCtx.createRadialGradient(480, 270, 120, 480, 270, 600);
    vg.addColorStop(0, 'rgba(120,0,16,0)');
    vg.addColorStop(1, `rgba(120,0,16,${.65 * a})`);
    uiCtx.fillStyle = vg;
    uiCtx.fillRect(0, 0, 960, 540);
    const k = clamp((t - .35) / .5, 0, 1);
    if (k > 0) {
        const s = 7, w = textWidth('YOU DIED', s) + 0;
        const sc2 = 1 + (1 - k) * .9;
        uiCtx.save();
        uiCtx.translate(480, 112);
        uiCtx.scale(sc2, sc2);
        const jit = t < .9 ? (rand() - .5) * 8 * (1 - t) : 0;
        drawText('YOU DIED', jit, -24, s, '#e02a3c', { al: 'c', sh: '#2a0008', out: '#07040f', a: k });
        uiCtx.restore();
    }
    const k2 = clamp((t - .9) / .4, 0, 1);
    if (k2 > 0) {
        uiCtx.textAlign = 'center';
        uiCtx.globalAlpha = k2;
        uiCtx.fillStyle = '#f4ead2';
        uiCtx.font = fontOf(24);
        uiCtx.fillText(deathState.quip, 480, 196);
        uiCtx.globalAlpha = 1;
        const bonusShown = Math.round(deathState.bonus * clamp((t - 1.1) / .8, 0, 1));
        panel(270, 216, 420, 104, .8);
        drawText('SCORE', 300, 232, 3, '#bfb8a0');
        drawText(String(deathState.score - deathState.bonus + bonusShown).padStart(6, '0'), 660, 228, 4, '#f2c14e', { al: 'r', sh: '#2a1c08' });
        drawText('BEST COMBO  X' + deathState.best, 300, 266, 2, '#ff8a3d');
        drawText(deathState.bonus ? 'COMBO BONUS +' + bonusShown : 'NO COMBO BONUS', 660, 266, 2, deathState.bonus ? '#9fe8c8' : '#7d7890', { al: 'r' });
        drawText('DEATHS ' + deaths, 300, 294, 2, '#bfb8a0');
    }
    const k3 = clamp((t - 1.3) / .4, 0, 1);
    if (k3 > 0) {
        const oy = (1 - k3) * 60;
        uiCtx.globalAlpha = k3;
        addBtn('replay', 170, 346 + oy, 300, 60, 'REPLAY MISSION', { s: 3, sel: deathState.sel == 0, dis: t < .9 });
        addBtn('restart', 490, 346 + oy, 300, 60, 'RESTART', { s: 3, sel: deathState.sel == 1, dis: t < .9 });
        drawText('RESUMES ' + stageSnapshot.kind.toUpperCase().replace('PLAY', 'LEVEL ' + stageSnapshot.lvl).replace('BOSS', 'THE BOSS').replace('ACT2', 'ACT II') + ' WITH', 320, 416 + oy, 2, '#bfb8a0', { al: 'c' });
        for (let i = 0; i < stageSnapshot.mh; i++) {
            mask(320 - stageSnapshot.mh * 8 + 8 + i * 16, 440 + oy, 7, i < stageSnapshot.hp);
        }
        drawText('HEARTS', 320, 454 + oy, 1, '#7d7890', { al: 'c' });
        drawText('FROM THE VERY START', 640, 416 + oy, 2, '#bfb8a0', { al: 'c' });
        if (!touchMode) {
            drawText('R REPLAY    X RESTART    ESC MENU', 480, 500 + oy, 2, '#7d7890', { al: 'c' });
        }
        uiCtx.globalAlpha = 1;
    }
}
/** Final score screen. */
function drawEnd() {
    uiCtx.fillStyle = 'rgba(0,0,0,.9)';
    uiCtx.fillRect(0, 0, 960, 540);
    uiCtx.textAlign = 'center';
    uiCtx.shadowColor = 'rgba(255,93,115,.7)';
    uiCtx.shadowBlur = 30;
    uiCtx.fillStyle = palette.acc;
    uiCtx.font = fontOf(54, 'italic bold');
    uiCtx.fillText('The narrator was the villain.', 480, 84);
    uiCtx.shadowBlur = 0;
    uiCtx.fillStyle = '#f4ead2';
    uiCtx.font = fontOf(24);
    uiCtx.fillText('He never fought a battle. He only told the story.', 480, 126);
    panel(190, 156, 580, 244, .85);
    const rows = [['ENEMY KILLS', scoreParts.kills], ['STAGE BONUSES', scoreParts.bonus], ['COMBO BONUSES', scoreParts.combo], ['HEARTS LEFT', scoreParts.hearts]];
    rows.forEach(([lab, val], i) => {
        const k = clamp((endT - .4 - i * .45) / .5, 0, 1);
        if (k <= 0) {
            return;
        }
        const y = 174 + i * 34;
        drawText(lab, 222, y, 3, '#f4ead2', { a: k, sh: '#000' });
        drawText('+' + Math.round(val * k), 740, y, 3, '#9fe8c8', { al: 'r', a: k, sh: '#000' });
    });
    const kt = clamp((endT - 2.3) / .6, 0, 1);
    if (kt > 0) {
        uiCtx.fillStyle = 'rgba(242,193,78,.5)';
        uiCtx.fillRect(222, 314, 516, 2);
        drawText('TOTAL', 222, 330, 4, '#f2c14e', { a: kt, sh: '#3a2a08' });
        const tot = score + comboBank;
        drawText(String(Math.round(tot * kt)).padStart(6, '0'), 740, 330, 5, '#f2c14e', { al: 'r', a: kt, sh: '#3a2a08' });
        drawText('KILLS ' + killCount + '   DEATHS ' + deaths + '   BEST COMBO X' + bestCombo + '   TIME ' + String(Math.floor(runTime / 60)).padStart(2, '0') + ':' + String(Math.floor(runTime % 60)).padStart(2, '0'), 480, 376, 2, '#bfb8a0', { al: 'c' });
    }
    const kr = clamp((endT - 3.1) / .4, 0, 1);
    if (kr > 0) {
        const rk = rankOf(score + comboBank), s = easeBounce(kr);
        uiCtx.save();
        uiCtx.translate(840, 278);
        uiCtx.scale(s, s);
        drawText('RANK', 0, -70, 3, '#bfb8a0', { al: 'c' });
        drawText(rk, 0, -30, 10, rk == 'S' ? '#ffe9a8' : rk == 'A' ? '#9fe8c8' : rk == 'B' ? '#9fc4ff' : '#c9b8e8', { al: 'c', sh: '#000', out: '#07040f' });
        uiCtx.restore();
        if (newBest) {
            drawText('NEW BEST!', 840, 360, 3, '#ffff55', { al: 'c', sh: '#3f3f15', a: .6 + Math.sin(time * 8) * .4 });
        }
    }
    if (endT > 3.5) {
        uiCtx.textAlign = 'center';
        uiCtx.fillStyle = 'rgba(244,234,210,.6)';
        uiCtx.font = fontOf(20);
        uiCtx.fillText('Thanks for playing', 480, 426);
        addBtn('credits_end', 365, 444, 230, 50, 'CONTINUE', { s: 3 });
    }
}
function drawFx() {
    popups.forEach(f => {
        const k = f.t / f.l, sx = (f.x - (gameState == 'play' && !f.fixed ? cameraX : 0)) * 3, sy = (f.y - f.t * 18) * 3;
        drawText(f.txt, sx, sy, f.s, f.col, { al: 'c', sh: '#000', a: clamp((1 - k) * 2.2, 0, 1) });
    });
}
function drawHud2() {
    const tot = Math.round(shownScore);
    drawText('SCORE', 924, 54, 2, '#bfb8a0', { al: 'r', sh: '#000' });
    const bs = 4 + (scoreBump > .5 ? 1 : 0);
    drawText(String(tot).padStart(6, '0'), 924, 68, bs, scoreBump > 0 ? '#ffffff' : '#f2c14e', { al: 'r', sh: '#2a1c08' });
    if (combo >= 2 && comboTimer > 0) {
        const col = combo >= 5 ? '#ff5d73' : combo >= 3 ? '#ff8a3d' : '#f2c14e', pop = 1 + Math.max(0, .4 - (3.2 - comboTimer)) * .8;
        drawText('COMBO X' + combo, 924, 106, 3, col, { al: 'r', sh: '#000', a: 1 });
        uiCtx.fillStyle = 'rgba(8,5,16,.7)';
        uiCtx.fillRect(784, 132, 140, 6);
        uiCtx.fillStyle = col;
        uiCtx.fillRect(784, 132, 140 * clamp(comboTimer / 3.2, 0, 1), 6);
    }
}
function drawBanner() {
    if (!banner) {
        return;
    }
    const t = banner.t, a = t < .4 ? t / .4 : t > 2.2 ? clamp((2.7 - t) / .5, 0, 1) : 1, e = Math.pow(clamp(t / .45, 0, 1), .5);
    uiCtx.globalAlpha = a;
    uiCtx.fillStyle = 'rgba(8,5,16,.72)';
    const bw = 960 * e;
    uiCtx.fillRect(480 - bw / 2, 150, bw, 92);
    uiCtx.fillStyle = 'rgba(242,193,78,.7)';
    uiCtx.fillRect(480 - bw / 2, 150, bw, 2);
    uiCtx.fillRect(480 - bw / 2, 240, bw, 2);
    drawText(banner.a, 480, 166, 7, '#f2c14e', { al: 'c', sh: '#3a2a08' });
    drawText(String(banner.b).toUpperCase(), 480, 222, 2, '#f4ead2', { al: 'c' });
    uiCtx.globalAlpha = 1;
}
// route: returns true when a full-screen screen (title/settings/intro) owns the UI layer
function drawMenus() {
    if (creditsOn) {
        drawCredits();
        return true;
    }
    if (gameState == 'title') {
        drawTitle();
        return true;
    }
    if (gameState == 'settings') {
        drawSettings();
        return true;
    }
    if (gameState == 'intro') {
        return true;
    }
    return false;
}
function drawOverlays() {
    drawFx();
    drawHud2();
    drawBanner();
    if (card == 2) {
        drawEnd();
    }
    if (paused) {
        drawPause();
    }
    if (deathState.on) {
        drawDead();
    }
    fadeRect();
}
function fadeRect() {
    if (fadeA > 0) {
        uiCtx.fillStyle = `rgba(0,0,0,${fadeA})`;
        uiCtx.fillRect(0, 0, 960, 540);
    }
}
